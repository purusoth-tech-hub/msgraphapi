﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using Model = ITOpsAutomation.O365Support.Entities.Entities;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ITOpsAutomation.O365Support.Api.Filters;
using Microsoft.Azure.Cosmos;

namespace ITOpsAutomation.O365Support.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExchangeOnlineController : ControllerBase
    {
        IExchangeOnlineService _exchangeOnlineService;

        private static string clientId;
        private static string clientSecret;
        private static string tenantId;
        public ExchangeOnlineController(IExchangeOnlineService exchangeOnlineService)
        {
            _exchangeOnlineService = exchangeOnlineService;
        }

        [HttpGet("UserById/{id}")]
        public async Task<IActionResult> UserById(string id)
        {
            try
            {
                clientId = Request.Headers[Common.Constants.HEADER_KEY_CLIENTID].FirstOrDefault();
                clientSecret = Request.Headers[Common.Constants.HEADER_KEY_CLIENTSECRET].FirstOrDefault();
                tenantId = Request.Headers[Common.Constants.HEADER_KEY_TENANTID].FirstOrDefault();

                if(clientId != null && clientSecret != null && tenantId != null)
                {
                    Model.AzureAD azureAD = new Model.AzureAD();
                    azureAD.ClientId = clientId;
                    azureAD.ClientSecret = clientSecret;
                    azureAD.TenantId = tenantId;
                    var _user = await _exchangeOnlineService.UserById(azureAD, id);
                    return Ok(_user);
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }            
        }

        [HttpPost("CreateUser")]
        public async Task<IActionResult> CreateUser([FromBody]Model.User user)
        {

            try
            {
                clientId = Request.Headers[Common.Constants.HEADER_KEY_CLIENTID].FirstOrDefault();
                clientSecret = Request.Headers[Common.Constants.HEADER_KEY_CLIENTSECRET].FirstOrDefault();
                tenantId = Request.Headers[Common.Constants.HEADER_KEY_TENANTID].FirstOrDefault();

                if (clientId != null && clientSecret != null && tenantId != null)
                {
                    Model.AzureAD azureAD = new Model.AzureAD();
                    azureAD.ClientId = clientId;
                    azureAD.ClientSecret = clientSecret;
                    azureAD.TenantId = tenantId;

                    var id = await _exchangeOnlineService.CreateUser(azureAD, user);
                    return Ok(id);
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }                 

        [HttpPost("DeleteUser/{id}")]
        public async Task<IActionResult> DeleteUser(string id)
        {
            try
            {
                clientId = Request.Headers[Common.Constants.HEADER_KEY_CLIENTID].FirstOrDefault();
                clientSecret = Request.Headers[Common.Constants.HEADER_KEY_CLIENTSECRET].FirstOrDefault();
                tenantId = Request.Headers[Common.Constants.HEADER_KEY_TENANTID].FirstOrDefault();

                if (clientId != null && clientSecret != null && tenantId != null)
                {
                    Model.AzureAD azureAD = new Model.AzureAD();
                    azureAD.ClientId = clientId;
                    azureAD.ClientSecret = clientSecret;
                    azureAD.TenantId = tenantId;

                    var flag = await _exchangeOnlineService.DeleteUser(azureAD, id);
                    return Ok(flag);

                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }            
        }

        [HttpPost("CreateContact/{ownerEmail}")]
        public async Task<IActionResult> CreateContact(string ownerEmail, [FromBody] Model.Contact contact)
        {
            try
            {
                clientId = Request.Headers[Common.Constants.HEADER_KEY_CLIENTID].FirstOrDefault();
                clientSecret = Request.Headers[Common.Constants.HEADER_KEY_CLIENTSECRET].FirstOrDefault();
                tenantId = Request.Headers[Common.Constants.HEADER_KEY_TENANTID].FirstOrDefault();

                if (clientId != null && clientSecret != null && tenantId != null)
                {
                    Model.AzureAD azureAD = new Model.AzureAD();
                    azureAD.ClientId = clientId;
                    azureAD.ClientSecret = clientSecret;
                    azureAD.TenantId = tenantId;

                    var id = await _exchangeOnlineService.CreateContact(azureAD, ownerEmail, contact);
                    return Ok(id);

                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            } 
           
        }

        [HttpPost("DeleteContact/{ownerEmail}/{contactEmail}")]
        public async Task<IActionResult> DeleteContact(string ownerEmail, string contactEmail)
        {
            try
            {
                clientId = Request.Headers[Common.Constants.HEADER_KEY_CLIENTID].FirstOrDefault();
                clientSecret = Request.Headers[Common.Constants.HEADER_KEY_CLIENTSECRET].FirstOrDefault();
                tenantId = Request.Headers[Common.Constants.HEADER_KEY_TENANTID].FirstOrDefault();

                if (clientId != null && clientSecret != null && tenantId != null)
                {
                    Model.AzureAD azureAD = new Model.AzureAD();
                    azureAD.ClientId = clientId;
                    azureAD.ClientSecret = clientSecret;
                    azureAD.TenantId = tenantId;

                    var flag = await _exchangeOnlineService.DeleteContact(azureAD, ownerEmail, contactEmail);
                    return Ok(flag);

                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        [HttpPost("CreateDistributionList")]
        public async Task<IActionResult> CreateDistributionList([FromBody] Model.DistributionList distributionList)
        {
            try
            {
                clientId = Request.Headers[Common.Constants.HEADER_KEY_CLIENTID].FirstOrDefault();
                clientSecret = Request.Headers[Common.Constants.HEADER_KEY_CLIENTSECRET].FirstOrDefault();
                tenantId = Request.Headers[Common.Constants.HEADER_KEY_TENANTID].FirstOrDefault();

                if (clientId != null && clientSecret != null && tenantId != null)
                {
                    Model.AzureAD azureAD = new Model.AzureAD();
                    azureAD.ClientId = clientId;
                    azureAD.ClientSecret = clientSecret;
                    azureAD.TenantId = tenantId;

                    var id = await _exchangeOnlineService.CreateDistributionList(azureAD, distributionList);
                    return Ok(id);

                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        [HttpPost("DeleteDistributionList/{id}")]
        public async Task<IActionResult> DeleteDistributionList(string id)
        {
            try
            {
                clientId = Request.Headers[Common.Constants.HEADER_KEY_CLIENTID].FirstOrDefault();
                clientSecret = Request.Headers[Common.Constants.HEADER_KEY_CLIENTSECRET].FirstOrDefault();
                tenantId = Request.Headers[Common.Constants.HEADER_KEY_TENANTID].FirstOrDefault();

                if (clientId != null && clientSecret != null && tenantId != null)
                {
                    Model.AzureAD azureAD = new Model.AzureAD();
                    azureAD.ClientId = clientId;
                    azureAD.ClientSecret = clientSecret;
                    azureAD.TenantId = tenantId;

                    var flag = await _exchangeOnlineService.DeleteDistributionList(azureAD, id);
                    return Ok(flag);

                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

    }
}
