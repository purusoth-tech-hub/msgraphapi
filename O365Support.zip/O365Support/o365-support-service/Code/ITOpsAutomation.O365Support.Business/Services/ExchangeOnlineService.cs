﻿using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using ITOpsAutomation.O365Support.Business.Gateway.Interfaces;
using ITOpsAutomation.O365Support.Data.Interfaces;
using Model = ITOpsAutomation.O365Support.Entities.Entities;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;
using System.Linq;

namespace ITOpsAutomation.O365Support.Business.Services
{
    public class ExchangeOnlineService : IExchangeOnlineService
    {
        IServiceNowGateway _serviceNowGateway;        
        public ExchangeOnlineService(IServiceNowGateway serviceNowGateway)
        {
            this._serviceNowGateway = serviceNowGateway;          
        }  
        public async Task<Model.User> UserById(Model.AzureAD azureAD, string id)
        {
            try
            {
                // Initialize the GraphServiceClient.
                GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);

                // Load group profile.
                 var _user = await client.Users[id].Request().GetAsync();
                 Model.User user = new Model.User();
                 if(_user != null){
                     user.id = _user.Id;
                     user.givenName = _user.GivenName;    
                     user.userPrincipalName = _user.UserPrincipalName;  
                     user.displayName = _user.DisplayName;
                     user.officeLocation = _user.OfficeLocation;
                 }
                return user;
            }
            catch (ServiceException ex)
            {
               throw ex;
            }
        } 
        public async Task<string> CreateUser(Model.AzureAD azureAD, Model.User userInfo)
        {
           try
           {
               // Initialize the GraphServiceClient.
               GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);
               Microsoft.Graph.User user = new Microsoft.Graph.User();

               Microsoft.Graph.PasswordProfile passwordProfile = new Microsoft.Graph.PasswordProfile();
                passwordProfile.Password = "Password@1234";
               //passwordProfile.Password = string.Format("Password@{0}", new Guid().ToString().Substring(0, 5));
               passwordProfile.ForceChangePasswordNextSignIn = true;
               user.PasswordProfile = passwordProfile;

               user.UserPrincipalName = userInfo.userPrincipalName;

               user.AccountEnabled = userInfo.accountEnabled;
               
               user.Country = userInfo.country;
               user.Department = userInfo.department;
               user.DisplayName = userInfo.displayName;
               user.GivenName = userInfo.givenName;
               user.Surname = userInfo.surname; 
               user.JobTitle = userInfo.jobTitle;
               user.MailNickname = userInfo.mailNickname == null ? userInfo.displayName.Replace(" ","") : userInfo.mailNickname;

               user.PasswordPolicies = "DisablePasswordExpiration";
                              
               user.StreetAddress = userInfo.streetAddress;
               user.City = userInfo.city;
               user.State = userInfo.state;    
               user.PostalCode = userInfo.postalCode;
               user.MobilePhone = userInfo.mobilePhone;
               user.OfficeLocation = userInfo.officeLocation;
               //user.UsageLocation = userInfo.usageLocation;              

               // Load group profile.
               var _user = await client.Users.Request().AddAsync(user);

               return _user.UserPrincipalName;
           }
           catch (ServiceException ex)
           {
              throw ex;
           }
        }       
        public async Task<bool> DeleteUser(Model.AzureAD azureAD, string id)
        {            
            try
            {
                // Initialize the GraphServiceClient.
                GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);

                if (!string.IsNullOrEmpty(id))
                {
                    var _user = client.Users[id].Request().DeleteAsync();                    
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (ServiceException ex)
            {
                throw ex;
            }
        }
        public async Task<bool> CreateContact(Model.AzureAD azureAD, string userId, Model.Contact contactInfo)
        {
            try
            {
                // Initialize the GraphServiceClient.
                GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);
                Microsoft.Graph.Contact contact = new Microsoft.Graph.Contact();
                contact.GivenName = contactInfo.contactName;
                contact.DisplayName = contactInfo.displayName;
                contact.MobilePhone = contactInfo.contactNumber;

                //Adding Email Address 
                EmailAddress emailAddress = new EmailAddress();
                emailAddress.Address = contactInfo.contactEmail;
                List<EmailAddress> emailAddresses = new List<EmailAddress>();
                emailAddresses.Add(emailAddress);
                contact.EmailAddresses = emailAddresses;

                var _contact = await client.Users[userId].Contacts.Request().AddAsync(contact);

                return true;
            }
            catch (ServiceException ex)
            {
                throw ex;
            }
        }
        public async Task<bool> DeleteContact(Model.AzureAD azureAD, string userId, string emailAddress)
        {
            try
            {
                // Initialize the GraphServiceClient.
                GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);

                string contactId = string.Empty;
                var contactList = await client.Users[userId].Contacts.Request().GetAsync();
                if (contactList != null && contactList.Count > 0)
                {
                    contactId = contactList.Where(i => i.EmailAddresses.FirstOrDefault().Address.ToLower() == emailAddress.ToLower()).FirstOrDefault().Id;
                    if (contactId != null)
                    {
                        var _contact = client.Users[userId].Contacts[contactId].Request().DeleteAsync();
                    }
                    else
                    {
                        throw new Exception(Common.Constants.USER_NOT_FOUND);
                    }
                }
                else
                {
                    throw new Exception(Common.Constants.CONTACTS_NOT_FOUND);
                }

                return true;
            }
            catch (ServiceException ex)
            {
                throw ex;
            }

        }
        public async Task<string> CreateDistributionList(Model.AzureAD azureAD, Model.DistributionList groupInfo)
        {
            try
            {
                // Initialize the GraphServiceClient.
                GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);

                if (groupInfo != null)
                {
                    if (groupInfo.groupTypes == null)
                    {
                        groupInfo.groupTypes = new List<string>()
                        {
                            Common.Constants.UNIFIED
                        };
                    }

                    var group = new Group
                    { 
                        DisplayName = groupInfo.displayName,
                        GroupTypes = groupInfo.groupTypes,
                        MailEnabled = true,
                        MailNickname = groupInfo.mailNickname == null ? groupInfo.displayName.Replace(" ", "") : groupInfo.mailNickname,
                        Description = groupInfo.displayName,
                        SecurityEnabled = false
                    };

                    var _group = await client.Groups.Request().AddAsync(group);

                    if (_group.Id != null)
                    {
                        
                        //Adding Group Owners
                        if (groupInfo.owners != null && groupInfo.owners.Count > 0)
                        {
                            var filteredOwners = groupInfo.owners.Distinct();
                            foreach (string owner in filteredOwners)
                            {
                                if (!string.IsNullOrEmpty(owner))
                                {
                                    var ownerUser = await client.Users[owner].Request().GetAsync();

                                    if (ownerUser != null)
                                    {
                                        var ownerAdded = client.Groups[_group.Id].Owners.References.Request().AddAsync(ownerUser);
                                    }
                                }
                            }
                        }

                        //Adding Group Members
                        if (groupInfo.members != null && groupInfo.members.Count > 0)
                        {
                            var filteredMembers = groupInfo.members.Distinct();
                            foreach (string member in filteredMembers)
                            {
                                if (!string.IsNullOrEmpty(member))
                                {
                                    var memberUser = await client.Users[member].Request().GetAsync();

                                    if (memberUser != null)
                                    {
                                        var membersAdded = client.Groups[_group.Id].Members.References.Request().AddAsync(memberUser);
                                    }
                                }
                            }
                        }
                    }

                    return _group.Id;
                }
                else
                {
                    throw new Exception(Common.Constants.INVALID_INPUT);
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public async Task<bool> DeleteDistributionList(Model.AzureAD azureAD, string id)
        {
            try
            {
                // Initialize the GraphServiceClient.
                GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);

                if(id != null)
                {
                    var groups = await client.Groups.Request().GetAsync();
                    var _group = groups.Where(g => g.Id == id || g.DisplayName == id).FirstOrDefault();
                    
                    if(_group != null && _group.Id != null)
                    {
                        var flag = client.Groups[_group.Id].Request().DeleteAsync();
                        return true;
                    }
                    else
                    {
                        throw new Exception(Common.Constants.DISTRIBUTION_LIST_NOT_FOUND);
                    }
                }
                else
                {
                    throw new Exception(Common.Constants.INVALID_INPUT);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
