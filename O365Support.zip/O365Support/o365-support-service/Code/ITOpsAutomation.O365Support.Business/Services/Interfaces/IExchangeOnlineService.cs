﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Model = ITOpsAutomation.O365Support.Entities.Entities;

namespace ITOpsAutomation.O365Support.Business.Services.Interfaces
{
    public interface IExchangeOnlineService 
    {
        Task<Model.User> UserById(Model.AzureAD azureAD, string id);
        Task<string> CreateUser(Model.AzureAD azureAD, Model.User user);
        Task<bool> DeleteUser(Model.AzureAD azureAD, string id);
        Task<bool> CreateContact(Model.AzureAD azureAD, string userId, Model.Contact contact);
        Task<bool> DeleteContact(Model.AzureAD azureAD, string userId, string emailAddress);
        Task<string> CreateDistributionList(Model.AzureAD azureAD, Model.DistributionList distributionGroup);
        Task<bool> DeleteDistributionList(Model.AzureAD azureAD, string id);

        // void UpdateDistributionList(Model.AzureAD azureAD, string id, DistributionGroup distributionGroup);
    }
}
