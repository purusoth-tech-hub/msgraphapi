﻿using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using ITOpsAutomation.O365Support.Business.Gateway.Interfaces;
using ITOpsAutomation.O365Support.Data.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITOpsAutomation.O365Support.Business.Services
{
    public class AssessService : IAssessService
    {
        IServiceNowGateway _serviceNowGateway;
        IGetById<MigrationDetail, string> _assessRepository;

        public AssessService(IServiceNowGateway serviceNowGateway, IGetById<MigrationDetail, string> assessRepository)
        {
            this._serviceNowGateway = serviceNowGateway;
            this._assessRepository = assessRepository;
        }

        public MigrationDetail GetById(string id)
        {
            return _assessRepository.GetById(id);
        }


    }
}
