﻿namespace ITOpsAutomation.O365Support.Data.Interfaces
{
    public interface IRepository<T, U> : IGetById<T, U>, IGetAll<T>, IDelete<U>,
                    ISave<T> where T : class
    {
    }

  
}
