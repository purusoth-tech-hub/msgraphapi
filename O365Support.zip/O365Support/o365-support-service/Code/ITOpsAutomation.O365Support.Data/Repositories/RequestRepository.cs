using ITOpsAutomation.O365Support.Data.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Core.Bindings;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Data.Repositories
{
    public class RequestRepository : IRequestRepository
    {
        private IMongoDBGateway _gateway;
        private string _collectionName = "Request";

        public RequestRepository(IMongoDBGateway gateway)
        {
            _gateway = gateway;
        }

        public IEnumerable<Request> GetByUser(string userEmailId)
        {
            var result = _gateway.GetMongoDB().GetCollection<Request>(_collectionName)
                         .Find(o => o.RequestDetails.UserEmailId == userEmailId)
                         .ToList();
            return result;
        }

        public Request Save(Request entity)
        {
           _gateway.GetMongoDB().GetCollection<Request>(_collectionName).InsertOne(entity);
            return entity;
        }

        public Request GetById(string id)
        {
            var result = _gateway.GetMongoDB().GetCollection<Request>(_collectionName)
                         .Find(o => o.RequestId == id)
                         .SingleOrDefault();
            return result;
        }

    }
}
