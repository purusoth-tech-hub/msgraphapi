
namespace ITOpsAutomation.O365Support.Common
{
    public static class Constants
    {
        public static string ASPNETCORE_ENVIRONMENT = "ASPNETCORE_ENVIRONMENT";
        public static string GRAPH_USERS_URL = @"https://graph.microsoft.com/v1.0/users";
        public static string OWNERS_ODATA_BIND = "\"owners@odata.bind\"";
        public static string MEMBERS_ODATA_BIND = "\"members@odata.bind\"";
        public static string UNIFIED = "Unified";
        public static string INSTANCE = "https://login.microsoftonline.com/";
        public static string GRAPH_RESOURCE = "https://graph.microsoft.com/";
        public static string GRAPH_RESOURCE_ENDPOINT = "v1.0";

        public static string CONTACTS_NOT_FOUND = "Contacts not found";
        public static string USER_NOT_FOUND = "User/Member not found";
        public static string DISTRIBUTION_LIST_NOT_FOUND = "Distribution List not found";
        public static string INVALID_INPUT = "Invalid input";


        public static string HEADER_KEY_CLIENTID = "clientId";
        public static string HEADER_KEY_CLIENTSECRET = "clientSecret";
        public static string HEADER_KEY_TENANTID = "TenantId";

    }
}