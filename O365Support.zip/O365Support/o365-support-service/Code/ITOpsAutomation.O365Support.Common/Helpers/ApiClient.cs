using System;
using System.Net;
using System.Net.Http;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text;
using Newtonsoft.Json;
using RestSharp.Authenticators;
using RestSharp.Deserializers;
using RestSharp.Serialization;
using Microsoft.Extensions.Configuration;
using RestSharp;
using ITOpsAutomation.O365Support.Common.Helpers.Interfaces;
using FluentValidation;

namespace ITOpsAutomation.O365Support.Common.Helpers
{
    public class ApiClient : IApiClient
    {
        private readonly IRestClient _restClient;
        public IConfiguration _configuration { get; }

        public ApiClient(IRestClient restClient)
        {
           this._restClient = restClient;
        }

        public async Task<T> Post<T>(string service, string action, T request, string authenticationType) where T : new()
        {
            var content = JsonConvert.SerializeObject(request); 
            _restClient.BaseUrl = ManageUrl(service,action);                
            _restClient.Authenticator = ManageAuthenticator(service,authenticationType);
            _restClient.AddDefaultHeader("Content-Type", "application/json");

            RestRequest restRequest = new RestRequest(Method.POST);
            restRequest.AddParameter("undefined", content, ParameterType.RequestBody);
            IRestResponse restResponse = await _restClient.ExecutePostAsync(restRequest);
            if(restResponse == null || (restResponse != null && restResponse.ResponseStatus != ResponseStatus.Completed))
            {
                HandleException(restResponse);  
            }
            return JsonConvert.DeserializeObject<T> (restResponse.Content); 
            
        }

        public Uri ManageUrl(string service, string action)
        {
            if(service == "ServiceNow" && action == "CreateRequest")
            {
                return new Uri(string.Format("{0}/api/RequestDetails/Create",_configuration["ServiceNowSettings:BaseUrl"]));
            }
            return new Uri("");
        }

        public HttpBasicAuthenticator ManageAuthenticator(string service, string authenticationType)
        {
            if(service == "ServiceNow" && authenticationType == "Basic")
            {
                return new HttpBasicAuthenticator(_configuration["ServiceNowSettings:Id"], _configuration["ServiceNowSettings:Password"]);
            }
            return new HttpBasicAuthenticator("","");
        }

        public void HandleException(IRestResponse restResponse)
        {
            if(restResponse.StatusCode == HttpStatusCode.InternalServerError)
            {
                throw new ApiException(restResponse.ErrorMessage);
            }
            else if(restResponse.StatusCode == HttpStatusCode.BadRequest)
            {
                throw new ValidationException(restResponse.ErrorMessage);
            }
        }   
    }
}
       