﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Entities.Entities
{
    public class Contact
    {
        public string id { get; set; }
        public string contactName { get; set; }
        public string contactNumber { get; set; }
        public string ownerEmail { get; set; }
        public string contactEmail { get; set; }
        public string displayName { get; set; }
    }
}
