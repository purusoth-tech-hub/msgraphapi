import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { DashboardComponent } from './dashboard/dashboard.component';
import { Configuration } from 'msal';
import { msalConfig, msalAngularConfig } from './app-config';
import { MsalAngularConfiguration, MsalInterceptor, MSAL_CONFIG, MSAL_CONFIG_ANGULAR, MsalService, MsalModule, MsalGuard } from '@azure/msal-angular';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
// import { MyRequestComponent } from './my-request/my-request.component';
// import { MyRequestDetailsComponent } from './my-request-details/my-request-details.component';
// import { ProductsComponent } from './products/products.component';
// import { HeaderComponent } from './header/header.component';
// import { FooterComponent } from './footer/footer.component';
import { AzureSupportModule } from './azure-support/azure-support.module';
import { AzureMigrationModule } from './azure-migration/azure-migration.module';
import { O365MigrationModule } from './o365-migration/o365-migration.module';
import { WvdModule } from './wvd/wvd.module';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AuthService } from './services/auth.service';
import { UserContextService } from './services/user-context.service';
import { AzureSupportComponent } from './azure-support/azure-support.component';
import { O365DashboardComponent } from './o365-migration/o365-dashboard/o365-dashboard.component';
import { ProductsComponent } from './o365-migration/products/products.component';
import { RequestsComponent } from './o365-migration/requests/requests.component';
import { ConnectAssessMigrateComponent } from './o365-migration/connect-assess-migrate/connect-assess-migrate.component';
import { HomeComponent } from './home/home.component';
import { DialogComponent } from './shared/dialog/dialog.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';

function MSALConfigFactory(): Configuration {
  return msalConfig;
}


function MSALAngularConfigFactory(): MsalAngularConfiguration {
  return msalAngularConfig;
}
const routes: Routes = [
  { path: 'o365', component: HomeComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [MsalGuard]
  },
  {
    path: 'azure-support/dashboard', component: AzureSupportComponent, canActivate: [
      MsalGuard
    ]
  },
  { path: '', redirectTo: 'o365/dashboard', pathMatch: 'full' }
];
@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    AppComponent,
    DashboardComponent,
    DashboardComponent,
    HomeComponent,
    DialogComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    AppRoutingModule,
    FormsModule,
    MsalModule,
    NgxPaginationModule,
    HttpClientModule,
    AzureSupportModule,
    AzureMigrationModule,
    O365MigrationModule,
    WvdModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes, { useHash: true })
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    },
    {
      provide: MSAL_CONFIG,
      useFactory: MSALConfigFactory
    },
    {
      provide: MSAL_CONFIG_ANGULAR,
      useFactory: MSALAngularConfigFactory
    },
    // {
    //   provide: HTTP_INTERCEPTORS,
    //   useClass: AuthenticationInterceptor,
    //   multi: true
    // },
    MsalService,
  ],
  bootstrap: [AppComponent],
  entryComponents: [DialogComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
