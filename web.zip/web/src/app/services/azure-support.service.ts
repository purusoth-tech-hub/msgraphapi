import { Injectable } from '@angular/core';
import { BroadcastService, MsalService } from '@azure/msal-angular';
import { b2cPolicies, tokenRequest, apiConfig } from '../app-config';
import { Logger, CryptoUtils } from 'msal';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AzureSupportService {
  baseUrl = 'https://app-itops-azure-support-dev.azurewebsites.net';
  accesToken = 'https://app-itops-azure-support-dev.azurewebsites.net';
  metrics: any;

  constructor(private msalService: MsalService, private _httpClient: HttpClient) {
    this.getTokenPopup(tokenRequest)
  }

  getTokenPopup(request) {
    return this.msalService.acquireTokenSilent(request)
      .catch(error => {
        console.log("Silent token acquisition fails. Acquiring token using popup");
        console.log(error);
        // fallback to interaction when silent call fails
        // return this.msalService.acquireTokenPopup(request)
        //   .then(tokenResponse => {
        //     console.log("access_token acquired at: " + new Date().toString());
        //     return tokenResponse;
        //   }).catch(error => {
        //     console.log(error);
        //   });
      });
  }

  passTokenToApi() {
    this.getTokenPopup(tokenRequest)
      .then(tokenResponse => {
        this.accesToken = tokenResponse["accessToken"];
        console.log("access_token acquired at: " + new Date().toString());
        try {
          console.log("Request made to Web API:");
          this.callApiWithAccessToken(apiConfig.webApi, tokenResponse["accessToken"]);
        } catch (err) {
          console.log(err);
        }
      });
  }

  callApiWithAccessToken(endpoint, token) {
    const headers = new Headers();
    const bearer = `Bearer ${token}`;

    headers.append("Authorization", bearer);

    const options = {
      method: "GET",
      headers: headers
    };

    fetch(this.baseUrl + "/Metrics", options)
      .then(response => response.json())
      .then(response => {
        this.metrics = response;
        console.log("Web API returned:\n" + JSON.stringify(response));
        return response;
      }).catch(error => {
        console.log("Error calling the Web api:\n" + error);
      });
  }


  fetchMetrics() {
    this.getTokenPopup(tokenRequest)
      .then(tokenResponse => {
        this.accesToken = tokenResponse["accessToken"];
        const headers = new HttpHeaders();
        const bearer = `Bearer ${this.accesToken}`;
        headers.append("Authorization", bearer);
        return this._httpClient.get(this.baseUrl + '/Metrics', { headers: headers });
      })
  };
}
