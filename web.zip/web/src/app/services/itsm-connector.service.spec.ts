import { TestBed } from '@angular/core/testing';

import { ItsmConnectorService } from './itsm-connector.service';

describe('ItsmConnectorService', () => {
  let service: ItsmConnectorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ItsmConnectorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
