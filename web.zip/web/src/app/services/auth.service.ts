import { Injectable } from '@angular/core';
import { BroadcastService, MsalService } from '@azure/msal-angular';
import { b2cPolicies } from '../app-config';
import { Logger, CryptoUtils } from 'msal';

@Injectable({
  providedIn : 'root'
})
export class AuthService {
  // loggedIn: any;
  
  public get loggedIn() : boolean {
    return !!this.msalService.getAccount();
  }
  
  isIframe: boolean = false;
  username: string;
  
  public get isLoggedIn() : boolean {
    return localStorage.getItem("isLoggedIn") ==  "true";
  }

  public set isLoggedIn(v : boolean) {
    localStorage.setItem("isLoggedIn" , String(v));
  }

  constructor(
    private msalService: MsalService,
    private broadcastService: BroadcastService,
    ) { }


  initializeAuthentication() {
    this.initializeAuthenticationComponents();
    if (!this.loggedIn)
      this.login();
    else
      this.username = this.msalService.getAccount().name;
  }

  initializeAuthenticationComponents()  {
    this.isIframe = window !== window.parent && !window.opener;
    // event listeners for authentication status
    this.broadcastService.subscribe('msal:loginSuccess', (success) => {
      // We need to reject id tokens that were not issued with the default sign-in policy.
      // "acr" claim in the token tells us what policy is used (NOTE: for new policies (v2.0), use "tfp" instead of "acr")
      // To learn more about b2c tokens, visit https://docs.microsoft.com/en-us/azure/active-directory-b2c/tokens-overview
      if (success.idToken.claims['tfp'] !== b2cPolicies.names.signUpSignIn) {
        return this.msalService.logout()
      }

      console.log('login succeeded. id token acquired at: ' + new Date().toString());
      console.log(success);

      this.isLoggedIn = true;
      this.username = this.msalService.getAccount().name;
    });

    this.broadcastService.subscribe('msal:loginFailure', (error) => {
      console.log('login failed');
      console.log(error);

      // Check for forgot password error
      // Learn more about AAD error codes at https://docs.microsoft.com/en-us/azure/active-directory/develop/reference-aadsts-error-codes
      if (error.errorMessage.indexOf('AADB2C90118') > -1) {
        this.msalService.loginRedirect(b2cPolicies.authorities.resetPassword);
      }
    });

    // redirect callback for redirect flow (IE)
    this.msalService.handleRedirectCallback((authError, response) => {
      if (authError) {
        console.error('Redirect Error: ', authError.errorMessage);
        return;
      }

      console.log('Redirect Success: ', response);
    });

    this.msalService.setLogger(new Logger((logLevel, message, piiEnabled) => {
      console.log('MSAL Logging: ', message);
    }, {
        correlationId: CryptoUtils.createNewGuid(),
        piiLoggingEnabled: false
      }));
  }


  login() {
    this.msalService.loginRedirect();
  }

  logout() {
    this.isLoggedIn = false;
    this.msalService.logout();
  }

}
