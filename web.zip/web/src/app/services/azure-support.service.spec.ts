import { TestBed } from '@angular/core/testing';

import { AzureSupportService } from './azure-support.service';

describe('AzureSupportService', () => {
  let service: AzureSupportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AzureSupportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
