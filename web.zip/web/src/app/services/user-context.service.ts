import { Injectable } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserContextService {
  baseUrl = 'https://app-itops-management-dev.azurewebsites.net';
  userDetails;
  constructor(
    private authService: MsalService, private http: HttpClient
  ) { }

  get email() {
    return !!this.authService.getAccount() ? this.authService.getAccount().idTokenClaims['emails'][0] : '';
  }

  get firstName(){
    return !!this.authService.getAccount() ? this.authService.getAccount().idTokenClaims['extension_FirstName'] : '';
  }

  get LastName(){
    return !!this.authService.getAccount() ? this.authService.getAccount().idTokenClaims['extension_LastName'] : '';
  }

  get company(){
    return !!this.authService.getAccount() ? this.authService.getAccount().idTokenClaims['extension_NameoftheCompany'] : '';
  }
  getSubscription() {
   return this.http.get(this.baseUrl + '/api/Customer/GetCustomerByEmail/' + 'abc@vodafone.com');
  }
}
