import { TestBed } from '@angular/core/testing';

import { O365Service } from './o365.service';

describe('O365Service', () => {
  let service: O365Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(O365Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
