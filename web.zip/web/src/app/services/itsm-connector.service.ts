import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ItsmConnectorService {
  baseUrl = 'https://app-itops-itsm-connector-dev.azurewebsites.net/api';

  constructor(private _http: HttpClient) { }

  createRequest(request) {
    return this._http.post(this.baseUrl + '/RequestDetails/Create', request);
  }

  getAllRequests() {
    return this._http.get(this.baseUrl + '/RequestDetails/GetAllByUser');
  }

  getAssessDetails(reqId: any) {
    let param = new HttpParams();
    param.append('requestId', reqId);
    let url = this.baseUrl + '/Assess/GetAssessDetails/' + reqId;
    return this._http.get(url);
  }

  getRequestDetails(id) {
    return this._http.get(this.baseUrl + '/RequestDetails/GetById/' + id);
  }

}
