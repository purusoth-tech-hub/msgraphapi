import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class O365Service {
  baseUrl = 'https://apm-dms-dev.azure-api.net/o365/vodafone/api';
  supportBaseUrl = "https://localhost:44367/api";
  clientId : string = "06c151fe-f63f-4070-8fdf-53b26246fb19";
  clientSecret : string = "QYLTmQiBf02zK3w454W2i__e2gQ-3_Nc-H";
  tenantId : string = "fbe96831-3e8d-40c2-b251-ee6bffb21e31";
  migrationType;
  serviceType; 



  constructor(private _http: HttpClient) {
    
   }

  login(username, password) {
    return this._http.post(this.baseUrl + '/login', {
      username: username, userPassword: password
    });
  }

  testConnection(token, url, adminUsername, adminPassword) {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + token
      })
    }
    return this._http.post(this.baseUrl + '/testconnection',
      {
        adminPassword: adminPassword, adminUsername: adminUsername, url: url
      },
      { ...httpOptions, responseType: 'text' });
  }

  createMailBox(user) {
    const httpOptions = {
      headers: new HttpHeaders({
        clientId : this.clientId,
        clientSecret : this.clientSecret,
        tenantId : this.tenantId
      })
    }
    console.log(user);
    return this._http.post(this.supportBaseUrl + '/exchangeonline/createuser', 
    user,
    { ...httpOptions, responseType: 'text' });
  }  

  DeleteMailBox(user) {    

    const httpOptions = {
      headers: new HttpHeaders({
        clientId : this.clientId,
        clientSecret : this.clientSecret,
        tenantId : this.tenantId
      })
    }
    
    if(user.userPrincipalName != null){
      return this._http.post(this.supportBaseUrl + '/ExchangeOnline/DeleteUser/' + user.userPrincipalName,
      user,
      { ...httpOptions, responseType: 'text' });
    }
    else if(user.mail != null){
      return this._http.post(this.supportBaseUrl + '/ExchangeOnline/DeleteUser/' + user.mail,
      user,
      { ...httpOptions, responseType: 'text' });
    }
  }

  createContact(contact) {
    const httpOptions = {
      headers: new HttpHeaders({
        clientId : this.clientId,
        clientSecret : this.clientSecret,
        tenantId : this.tenantId
      })
    }
    return this._http.post(this.supportBaseUrl + '/exchangeonline/createcontact/' + contact.ownerEmail,
    contact,
    { ...httpOptions, responseType: 'text' });

  }

  deleteContact(contact) {
    console.log("delete contact service called"); 
    const httpOptions = {
      headers: new HttpHeaders({
        clientId : this.clientId,
        clientSecret : this.clientSecret,
        tenantId : this.tenantId
      })
    }
     if(contact.mail != null){
      return this._http.post(this.supportBaseUrl + '/ExchangeOnline/deletecontact/' + contact.ownerEmail + "/" + contact.email, 
      contact,
      { ...httpOptions, responseType: 'text' });
    }
  }

  createDistributionList(distributionList) {
   
    const httpOptions = {
      headers: new HttpHeaders({
        clientId : this.clientId,
        clientSecret : this.clientSecret,
        tenantId : this.tenantId
      })
    }
    console.log(distributionList);
    return this._http.post(this.supportBaseUrl + '/exchangeonline/CreateDistributionList',
    distributionList,
    { ...httpOptions, responseType: 'text' });
    
  }

  deleteDistributionList(distributionList) {
    console.log("delete distribution list service called"); 
    const httpOptions = {
      headers: new HttpHeaders({
        clientId : this.clientId,
        clientSecret : this.clientSecret,
        tenantId : this.tenantId
      })
    }
     if(distributionList.displayName != null){
      return this._http.post(this.supportBaseUrl + '/ExchangeOnline/DeleteDistributionList/' + distributionList.displayName, 
      distributionList,
      { ...httpOptions, responseType: 'text' });
    }
  }

}
