import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AzureSupportComponent } from './azure-support.component';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from '../app-routing.module';
import { MsalModule } from '@azure/msal-angular';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [AzureSupportComponent],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    MsalModule,
    HttpClientModule
  ]
})
export class AzureSupportModule { }
