import { Component, OnInit } from '@angular/core';
import { AzureSupportService } from '../services/azure-support.service';

@Component({
  selector: 'app-azure-support',
  templateUrl: './azure-support.component.html',
  styleUrls: ['./azure-support.component.css']
})
export class AzureSupportComponent implements OnInit {

  // perfOutput = new PerfOutput();
  // performances : [];


  constructor(private api: AzureSupportService) { }

  ngOnInit() {
    this.api.passTokenToApi();
  }

  get performances() {
    return !!this.api.metrics && this.api.metrics.length > 0 ? this.api.metrics : [];
  }

}
