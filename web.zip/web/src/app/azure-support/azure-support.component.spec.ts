import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AzureSupportComponent } from './azure-support.component';

describe('AzureSupportComponent', () => {
  let component: AzureSupportComponent;
  let fixture: ComponentFixture<AzureSupportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AzureSupportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AzureSupportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
