import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { O365ServiceCatalogComponent } from './o365-service-catalog.component';

describe('O365ServiceCatalogComponent', () => {
  let component: O365ServiceCatalogComponent;
  let fixture: ComponentFixture<O365ServiceCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ O365ServiceCatalogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(O365ServiceCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
