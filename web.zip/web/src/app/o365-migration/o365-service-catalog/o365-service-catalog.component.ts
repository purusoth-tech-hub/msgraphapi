import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserContextService } from 'src/app/services/user-context.service';
import { DialogComponent } from 'src/app/shared/dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';
declare let $;

@Component({
  selector: 'app-o365-service-catalog',
  templateUrl: './o365-service-catalog.component.html',
  styleUrls: ['./o365-service-catalog.component.css']
})
export class O365ServiceCatalogComponent implements OnInit {
  userDetails: any;  
  
  constructor(private _router: Router, private _userContext: UserContextService, public dialog: MatDialog) { }

  ngOnInit(): void {
  }
  
  exchangeOnlieCreateMailBoxClicked() {
    this._userContext.getSubscription().subscribe(x => {
      this.userDetails = x;
      if (this.userDetails.supportServices.find(x => x.service == "O365MigrateAndSupport")) {
        this._router.navigate(['/o365/exchangeOnlineCreateMailBox'])
      }
      else {
        $('#warning').modal('show');
      }
    });

  }

  exchangeOnlieDeleteMailBoxClicked() {
    this._userContext.getSubscription().subscribe(x => {
      this.userDetails = x;
      if (this.userDetails.supportServices.find(x => x.service == "O365MigrateAndSupport")) {
        this._router.navigate(['/o365/exchangeOnlineDeleteMailBox'])
      }
      else {
        $('#warning').modal('show');
      }
    });
  }

  exchangeOnlieCreateContactClicked() {
    this._userContext.getSubscription().subscribe(x => {
      this.userDetails = x;
      if (this.userDetails.supportServices.find(x => x.service == "O365MigrateAndSupport")) {
        this._router.navigate(['/o365/exchangeOnlineCreateContact'])
      }
      else {
        $('#warning').modal('show');
      }
    });
  }

  exchangeOnlieDeleteContactClicked() {
    this._userContext.getSubscription().subscribe(x => {
      this.userDetails = x;
      if (this.userDetails.supportServices.find(x => x.service == "O365MigrateAndSupport")) {
        this._router.navigate(['/o365/exchangeOnlineDeleteContact'])
      }
      else {
        $('#warning').modal('show');
      }
    });
  }

  exchangeOnlieCreateDistrubutionListClicked() {
    this._userContext.getSubscription().subscribe(x => {
      this.userDetails = x;
      if (this.userDetails.supportServices.find(x => x.service == "O365MigrateAndSupport")) {
        this._router.navigate(['/o365/exchangeOnlineCreateDistributionList'])
      }
      else {
        $('#warning').modal('show');
      }
    });
  }

  exchangeOnlieDeleteDistrubutionListClicked() {
    this._userContext.getSubscription().subscribe(x => {
      this.userDetails = x;
      if (this.userDetails.supportServices.find(x => x.service == "O365MigrateAndSupport")) {
        this._router.navigate(['/o365/exchangeOnlineDeleteDistributionList'])
      }
      else {
        $('#warning').modal('show');
      }
    });
  }

}
