import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { O365DashboardComponent } from './o365-dashboard/o365-dashboard.component';
import { ProductsComponent } from './products/products.component';
import { ConnectAssessMigrateComponent } from './connect-assess-migrate/connect-assess-migrate.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConnectComponent } from './connect-assess-migrate/connect/connect.component';
import { AssesComponent } from './connect-assess-migrate/asses/asses.component';
import { MigrateComponent } from './connect-assess-migrate/migrate/migrate.component';
import { RequestsComponent } from './requests/requests.component';
import { RequestsListComponent } from './requests/requests-list/requests-list.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { RouterModule } from '@angular/router';
import { RequestDetailsComponent } from './requests/request-details/request-details.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { O365ServiceCatalogComponent } from './o365-service-catalog/o365-service-catalog.component';
import { O365ExchangeOnlineCreatemailboxComponent } from './o365-exchange-online-createmailbox/o365-exchange-online-createmailbox.component';
import { O365ExchangeOnlineDeletemailboxComponent } from './o365-exchange-online-deletemailbox/o365-exchange-online-deletemailbox.component';
import { O365ExchangeOnlineCreateContactComponent } from './o365-exchange-online-create-contact/o365-exchange-online-create-contact.component';
import { O365ExchangeOnlineDeleteContactComponent } from './o365-exchange-online-delete-contact/o365-exchange-online-delete-contact.component';
import { O365ExchangeOnlineCreateDistributionListComponent } from './o365-exchange-online-create-distribution-list/o365-exchange-online-create-distribution-list.component';
import { O365ExchangeOnlineDeleteDistributionListComponent } from './o365-exchange-online-delete-distribution-list/o365-exchange-online-delete-distribution-list.component';



@NgModule({
  declarations: [O365DashboardComponent, ProductsComponent, ConnectAssessMigrateComponent, ConnectComponent, AssesComponent, MigrateComponent, RequestsComponent, RequestsListComponent, RequestDetailsComponent, O365ServiceCatalogComponent, O365ExchangeOnlineCreatemailboxComponent, O365ExchangeOnlineDeletemailboxComponent, O365ExchangeOnlineCreateContactComponent, O365ExchangeOnlineDeleteContactComponent, O365ExchangeOnlineCreateDistributionListComponent, O365ExchangeOnlineDeleteDistributionListComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    MatNativeDateModule
  ]
})
export class O365MigrationModule { }
