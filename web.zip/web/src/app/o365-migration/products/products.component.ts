import { Component, OnInit } from '@angular/core';
import { UserContextService } from 'src/app/services/user-context.service';
import { Router } from '@angular/router';
import { O365Service } from 'src/app/services/o365.service';
declare let $;
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  userDetails;
  migration;
  constructor(private _userContext: UserContextService, private _router: Router, private _o365Service: O365Service) {
    this._userContext.getSubscription().subscribe(x => {
      this.userDetails = x;
      if (!this.userDetails.supportServices.find(x => x.service == "O365MigrateAndSupport")) {
        this._router.navigate(['/'])
      }
    });
   }

  ngOnInit() {
   
  }

  ShowChoosemigrationPopup() {
      $('#prerequisiteModal').modal('hide');
      $('#choosemigration').modal('show');
    }

    get isSubmitEnabled(){
      this._o365Service.migrationType = this.migration;
      return !!this.migration; 
    }

    submitForMigration(){
      $('#choosemigration').modal('hide');
      this._router.navigate(['/o365/migrate']);
    }
}
