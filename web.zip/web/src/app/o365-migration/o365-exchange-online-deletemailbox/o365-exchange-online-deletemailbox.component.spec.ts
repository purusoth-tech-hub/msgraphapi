import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { O365ExchangeOnlineDeletemailboxComponent } from './o365-exchange-online-deletemailbox.component';

describe('O365ExchangeOnlineDeletemailboxComponent', () => {
  let component: O365ExchangeOnlineDeletemailboxComponent;
  let fixture: ComponentFixture<O365ExchangeOnlineDeletemailboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ O365ExchangeOnlineDeletemailboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(O365ExchangeOnlineDeletemailboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
