import { Component, OnInit, Input } from '@angular/core';
import { ItsmConnectorService } from 'src/app/services/itsm-connector.service';
import { Assess } from 'src/app/models/assess';
@Component({
  selector: 'app-asses',
  templateUrl: './asses.component.html',
  styleUrls: ['./asses.component.css']
})
export class AssesComponent implements OnInit {
  @Input('requestNumber') requestNumber: any;
  licenseType: string;
  licensesType: any[] = [
    {
      id: 1,
      name: "Office 365 Business Essentials"
    },
    {
      id: 2,
      name: "Office 365 Business Premium"
    },
    {
      id: 3,
      name: "Office 365 Exchange Online Only"
    },
    {
      id: 4,
      name: "Enterprise Plan E"
    },
    {
      id: 5,
      name: "Office 365 (Plan E2)"
    }
  ]
  assessDetails: Assess;
  p: number = 1;
  constructor(private _itsmConnectorService: ItsmConnectorService) { }

  ngOnInit(): void {
    this._itsmConnectorService.getAssessDetails(this.requestNumber).subscribe((res: Assess) => {
      res.licensesDetail.userDetails.forEach(user => {
        user.licenseType = this.getLicenseType(user.licenseType);
      })
      this.assessDetails = res;
    });
  }
  getFormattedDate(date: string) {
    return date.substr(0, 10);
  }
  getLicenseType(index: any) {
    return this.licensesType.find(license => license.id === index);
  }

}
