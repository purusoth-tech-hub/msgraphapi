import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssesComponent } from './asses.component';

describe('AssesComponent', () => {
  let component: AssesComponent;
  let fixture: ComponentFixture<AssesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
