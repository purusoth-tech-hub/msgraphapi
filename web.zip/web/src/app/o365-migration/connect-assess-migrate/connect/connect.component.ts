import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, Validators, FormControlName } from '@angular/forms';
declare let $;
@Component({
  selector: 'app-connect',
  templateUrl: './connect.component.html',
  styleUrls: ['./connect.component.css']
})
export class ConnectComponent implements OnInit {
  @Input() connectFormGroup: FormGroup
  @Input() connectionStatus;
  @Input() requestNumber;
  @Input() inProgress;
  @Input() connectionRequested;
  @Input() requestDetails;
  @Input() connectionFailed;
  constructor() { }

  ngOnInit(): void {
   
  }

  ngAfterViewInit(){
    $(".js-form-item").bind("click", function () {
      $(this).addClass('form-item--input-filled');
    });
    
    $(".form-item__input").bind("blur", function () {
      if($(this).val() === '') {
          $(this).parent('.js-form-item').removeClass('form-item--input-filled');
      }
    }).bind("focus", function () {
      $(this).parent('.js-form-item').addClass('form-item--input-filled');
    });
  }
  showConfirmation(){
    $('#connectsubmitModal').modal('show');
  }

  get isValidationSuccess(){
   return !this.connectFormGroup.invalid
  }

  get request(){
    return this.requestDetails;
  }

}
