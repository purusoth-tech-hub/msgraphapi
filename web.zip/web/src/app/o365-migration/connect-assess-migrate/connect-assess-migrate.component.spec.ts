import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectAssessMigrateComponent } from './connect-assess-migrate.component';

describe('ConnectAssessMigrateComponent', () => {
  let component: ConnectAssessMigrateComponent;
  let fixture: ComponentFixture<ConnectAssessMigrateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConnectAssessMigrateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectAssessMigrateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
