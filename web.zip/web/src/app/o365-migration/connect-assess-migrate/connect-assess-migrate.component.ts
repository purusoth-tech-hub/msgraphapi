import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ItsmConnectorService } from 'src/app/services/itsm-connector.service';
import { Request, RequestDetail } from 'src/app/models/request';
import { O365Service } from 'src/app/services/o365.service';
import { Router, ActivatedRoute } from '@angular/router';
declare let $;
@Component({
  selector: 'app-connect-assess-migrate',
  templateUrl: './connect-assess-migrate.component.html',
  styleUrls: ['./connect-assess-migrate.component.css']
})
export class ConnectAssessMigrateComponent implements OnInit {
  connectionStatus;
  connectFormGroup: FormGroup;
  requestNumber: string;
  inProgress: boolean;
  connectionRequested: boolean;
  requestDetails: Request;
  connectionFailed: boolean;
  constructor(private _itsmConnectorService: ItsmConnectorService, private _router: Router,
    private _route: ActivatedRoute,
    private _o365Service: O365Service) {
    this.connectFormGroup = new FormGroup({
      onPremiseExchangeURL: new FormControl('', Validators.required),
      sourceAdminUserName: new FormControl('', Validators.required),
      sourceAdminPassword: new FormControl('', Validators.required),
      o365TenantURL: new FormControl('', Validators.required),
      targetAdminUserName: new FormControl('', Validators.required),
      targetAdminPassword: new FormControl('', Validators.required),
      dnsURL: new FormControl('', Validators.required),
      dnsAdminUserName: new FormControl('', Validators.required),
      dnsAdminPassword: new FormControl('', Validators.required),
      vpnURL: new FormControl('', Validators.required),
      vpnAdminUserName: new FormControl('', Validators.required),
      vpnPassword: new FormControl('', Validators.required)
    })
  }

  ngOnInit(): void {
    this._route.queryParams.subscribe(params => {
      this.requestNumber = params['requestNumber'];
      if (!!this.requestNumber) {
        this._itsmConnectorService.getRequestDetails(this.requestNumber).subscribe((res: Request) => {
          this.requestDetails = res;
          this.connectionStatus = res.status;
        });
      }
    });
  }

  proceedForMigration() {
    this.inProgress = true;
    $('#connectsubmitModal').modal('hide');
    let request = new Request();
    request.requestType = 'O365MigrateAndSupport';
    request.requestDetails = new RequestDetail();
    request.requestDetails.migrationType = this._o365Service.migrationType;
    request.requestDetails.sourceConnection = {
      url: this.connectFormGroup.value.onPremiseExchangeURL,
      userName: this.connectFormGroup.value.sourceAdminUserName,
      password: this.connectFormGroup.value.sourceAdminPassword
    };
    request.requestDetails.targetConnection = {
      url: this.connectFormGroup.value.o365TenantURL,
      userName: this.connectFormGroup.value.targetAdminUserName,
      password: this.connectFormGroup.value.targetAdminPassword
    };
    request.requestDetails.dnsConnection = {
      url: this.connectFormGroup.value.dnsURL,
      userName: this.connectFormGroup.value.dnsAdminUserName,
      password: this.connectFormGroup.value.dnsAdminPassword
    };
    request.requestDetails.vpnConnection = {
      url: this.connectFormGroup.value.vpnURL,
      userName: this.connectFormGroup.value.vpnAdminUserName,
      password: this.connectFormGroup.value.vpnPassword
    };
    request.status = 'Pending';
    this._o365Service.login('Admin', 'Password123').subscribe((token: any) => {
      this._o365Service.testConnection(token.jwtAccessToken, this.connectFormGroup.value.onPremiseExchangeURL,
        this.connectFormGroup.value.sourceAdminUserName, this.connectFormGroup.value.sourceAdminPassword)
        .subscribe((res: string) => {
          this._itsmConnectorService.createRequest(request).subscribe((data: Request) => {
            this.connectionRequested = true;
            this.requestNumber = data.requestId;
            this.inProgress = false;
            this.connectionStatus = data.status;
            this._router.navigate(['/o365/migrate'], { queryParams: { requestNumber: data.requestId }, queryParamsHandling: "merge" });
          }, err => {
            this.inProgress = false;
          });
        }, err => {
          this.connectionFailed = true;
          this.inProgress = false;
        });
    }, (err) => {
      this.inProgress = false;
    });
  }
  tabClicked() {
    $("div.bhoechie-tab-menu>div.list-group>a").click(function (e) {
      e.preventDefault();
      $(this).siblings('a.active').removeClass("active");
      $(this).addClass("active");
      var index = $(this).index();
      $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
      $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
  }
}
