import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-migrate',
  templateUrl: './migrate.component.html',
  styleUrls: ['./migrate.component.css']
})
export class MigrateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
