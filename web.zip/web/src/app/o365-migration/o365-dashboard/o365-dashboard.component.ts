import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserContextService } from 'src/app/services/user-context.service';
import { DialogComponent } from 'src/app/shared/dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';
declare let $;
@Component({
  selector: 'app-o365-dashboard',
  templateUrl: './o365-dashboard.component.html',
  styleUrls: ['./o365-dashboard.component.css']
})
export class O365DashboardComponent implements OnInit {
  userDetails: any;  
  constructor(private _router: Router, private _userContext: UserContextService, public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  exchangeOnlieMigrationClicked() {
    this._userContext.getSubscription().subscribe(x => {
      this.userDetails = x;
      if (this.userDetails.supportServices.find(x => x.service == "O365MigrateAndSupport")) {
        this._router.navigate(['/o365/product'])
      }
      else {
        $('#warning').modal('show');
      }
    });

  }

  exchangeOnlineSupportClicked() {
    this._userContext.getSubscription().subscribe(x => {
      this.userDetails = x;
      if (this.userDetails.supportServices.find(x => x.service == "O365MigrateAndSupport")) {
        this._router.navigate(['/o365/supportServiceCatalog'])
      }
      else {
        $('#warning').modal('show');
      }
    });

  }

  openDialog(): void {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      height: '190px'
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        console.log('Yes clicked');
      }
    });

  }
}
