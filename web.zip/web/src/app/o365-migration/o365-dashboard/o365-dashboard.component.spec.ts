import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { O365DashboardComponent } from './o365-dashboard.component';

describe('O365DashboardComponent', () => {
  let component: O365DashboardComponent;
  let fixture: ComponentFixture<O365DashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ O365DashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(O365DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
