import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { O365ExchangeOnlineDeleteContactComponent } from './o365-exchange-online-delete-contact.component';

describe('O365ExchangeOnlineDeleteContactComponent', () => {
  let component: O365ExchangeOnlineDeleteContactComponent;
  let fixture: ComponentFixture<O365ExchangeOnlineDeleteContactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ O365ExchangeOnlineDeleteContactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(O365ExchangeOnlineDeleteContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
