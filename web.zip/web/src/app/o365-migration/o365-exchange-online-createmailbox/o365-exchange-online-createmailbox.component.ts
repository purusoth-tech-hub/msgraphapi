import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ItsmConnectorService } from 'src/app/services/itsm-connector.service';
import { User } from 'src/app/models/user';
import { O365Service } from 'src/app/services/o365.service';
import { Router, ActivatedRoute } from '@angular/router';
declare let $;

@Component({
  selector: 'app-o365-exchange-online-createmailbox',
  templateUrl: './o365-exchange-online-createmailbox.component.html',
  styleUrls: ['./o365-exchange-online-createmailbox.component.css']
})
export class O365ExchangeOnlineCreatemailboxComponent implements OnInit {
  inProgress: boolean;
  userMailBox: FormGroup;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _o365Service: O365Service) {
    this.userMailBox = new FormGroup({   
      Id: new FormControl('', Validators.required),
      userPrincipalName: new FormControl('', Validators.required),
      displayName: new FormControl('', Validators.required),
      officeLocation: new FormControl('', Validators.required),
      mail: new FormControl('', Validators.required),
      license: new FormControl('', Validators.required)      
    });
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(){
    $(".js-form-item").bind("click", function () {
      $(this).addClass('form-item--input-filled');
    });
    
    $(".form-item__input").bind("blur", function () {
      if($(this).val() === '') {
          $(this).parent('.js-form-item').removeClass('form-item--input-filled');
      }
    }).bind("focus", function () {
      $(this).parent('.js-form-item').addClass('form-item--input-filled');
    });
  }

  createMailBox() {
    this.inProgress = true;
    
    let user = new User();
    user.userPrincipalName = this.userMailBox.value.userPrincipalName;
    user.displayName = this.userMailBox.value.displayName;
    user.mail = this.userMailBox.value.mail;
    user.officeLocation = this.userMailBox.value.officeLocation;
    user.license = this.userMailBox.value.license;
      console.log(user);
      this._o365Service.createMailBox(user)
        .subscribe((res: string) => {
          alert("MailBox Created Successfully ");
        }, err => {
          alert("MailBox Created Successfully ");
          this.inProgress = false;
        });    
  }

  cancelClick(){
    console.log("cancel clicked");
    this._router.navigate(['/o365/supportServiceCatalog']);
  }


}
