import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { O365ExchangeOnlineCreatemailboxComponent } from './o365-exchange-online-createmailbox.component';

describe('O365ExchangeOnlineCreatemailboxComponent', () => {
  let component: O365ExchangeOnlineCreatemailboxComponent;
  let fixture: ComponentFixture<O365ExchangeOnlineCreatemailboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ O365ExchangeOnlineCreatemailboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(O365ExchangeOnlineCreatemailboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
