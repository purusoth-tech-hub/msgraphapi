import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { O365ExchangeOnlineCreateContactComponent } from './o365-exchange-online-create-contact.component';

describe('O365ExchangeOnlineCreateContactComponent', () => {
  let component: O365ExchangeOnlineCreateContactComponent;
  let fixture: ComponentFixture<O365ExchangeOnlineCreateContactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ O365ExchangeOnlineCreateContactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(O365ExchangeOnlineCreateContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
