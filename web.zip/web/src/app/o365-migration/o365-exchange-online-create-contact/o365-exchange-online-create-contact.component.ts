import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ItsmConnectorService } from 'src/app/services/itsm-connector.service';
import { Contact } from 'src/app/models/contact';
import { O365Service } from 'src/app/services/o365.service';
import { Router, ActivatedRoute } from '@angular/router';
declare let $;


@Component({
  selector: 'app-o365-exchange-online-create-contact',
  templateUrl: './o365-exchange-online-create-contact.component.html',
  styleUrls: ['./o365-exchange-online-create-contact.component.css']
})
export class O365ExchangeOnlineCreateContactComponent implements OnInit {

  inProgress: boolean;
  userContact: FormGroup;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _o365Service: O365Service) {
    this.userContact = new FormGroup({   
      Id: new FormControl('', Validators.required),
      ownerEmail: new FormControl('', Validators.required),
      contactName: new FormControl('', Validators.required),
      displayName: new FormControl('', Validators.required),
      contactNumber: new FormControl('', Validators.required),
      contactEmail: new FormControl('', Validators.required)         
    });
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(){
    $(".js-form-item").bind("click", function () {
      $(this).addClass('form-item--input-filled');
    });
    
    $(".form-item__input").bind("blur", function () {
      if($(this).val() === '') {
          $(this).parent('.js-form-item').removeClass('form-item--input-filled');
      }
    }).bind("focus", function () {
      $(this).parent('.js-form-item').addClass('form-item--input-filled');
    });
  }

  createContact() {
    this.inProgress = true;
    
    let contact = new Contact();
    contact.ownerEmail = this.userContact.value.ownerEmail;
    contact.contactName = this.userContact.value.contactName;
    contact.contactNumber = this.userContact.value.contactNumber;
    contact.contactEmail = this.userContact.value.contactEmail;
    contact.displayName = this.userContact.value.displayName;    
    
    console.log(contact);
    this._o365Service.createContact(contact)
      .subscribe((res: string) => {
        alert("Contact Created Successfully ");
      }, err => {
        alert("Contact Created Successfully ");
        this.inProgress = false;
      });    
  }

  cancelClick(){
    this._router.navigate(['/o365/supportServiceCatalog']);
  }
}
