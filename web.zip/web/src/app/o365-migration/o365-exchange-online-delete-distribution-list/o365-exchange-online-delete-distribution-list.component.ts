import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ItsmConnectorService } from 'src/app/services/itsm-connector.service';
import { DistributionList } from 'src/app/models/distributionList';
import { O365Service } from 'src/app/services/o365.service';
import { Router, ActivatedRoute } from '@angular/router';
declare let $;

@Component({
  selector: 'app-o365-exchange-online-delete-distribution-list',
  templateUrl: './o365-exchange-online-delete-distribution-list.component.html',
  styleUrls: ['./o365-exchange-online-delete-distribution-list.component.css']
})
export class O365ExchangeOnlineDeleteDistributionListComponent implements OnInit {
  inProgress: boolean;
  formGroupDistributionList: FormGroup;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _o365Service: O365Service) {
    this.formGroupDistributionList = new FormGroup({   
      Id: new FormControl('', Validators.required),      
      displayName: new FormControl('', Validators.required)       
    });
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(){
    $(".js-form-item").bind("click", function () {
      $(this).addClass('form-item--input-filled');
    });
    
    $(".form-item__input").bind("blur", function () {
      if($(this).val() === '') {
          $(this).parent('.js-form-item').removeClass('form-item--input-filled');
      }
    }).bind("focus", function () {
      $(this).parent('.js-form-item').addClass('form-item--input-filled');
    });
  }

  deleteDistributionList() {
    this.inProgress = true;
    
    let distributionList = new DistributionList();    
    distributionList.displayName = this.formGroupDistributionList.value.displayName;    
    
      console.log(distributionList);
      this._o365Service.deleteDistributionList(distributionList)
        .subscribe((res: string) => {
          alert("Distribution List Created Successfully ");
        }, err => {
          alert("Distribution List Created Successfully ");
          this.inProgress = false;
        });    
  }

  cancelClick(){
    this._router.navigate(['/o365/supportServiceCatalog']);
  }


}
