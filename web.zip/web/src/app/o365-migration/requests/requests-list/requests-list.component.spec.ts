import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestsListComponent } from './requests-list.component';
import { Observable, of } from 'rxjs';
import { ItsmConnectorService } from 'src/app/services/itsm-connector.service';
import { UserContextService } from 'src/app/services/user-context.service';
import { NgxPaginationModule } from 'ngx-pagination';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { kMaxLength } from 'buffer';
import { FormControl } from '@angular/forms';
import { eventNames } from 'process';
class MockItsmConnectorService {
  getAllRequests(): Observable<any> {
    return of([
      {
        requestId: "5f3cf6b8cb5843f81fc5bfff",
        requestType: "O365Migration",
        status: "Successful",
        createdOn: "7/19/2020",
        updatedOn: "8/19/2020",
        requestDetails: {
          userName: "Manu",
          userPassword: "manu@123",
          userEmailId: "manu123@gmail.com",
          migrationType: "Advanced",
          domainName: "www.godaddy.com",
        }
      },
      {
        requestId: "5f3cf6b8cb5843f81fc5b000",
        requestType: "Migration",
        status: "Pending",
        createdOn: "8/19/2020",
        updatedOn: "8/19/2020",
        requestDetails: {
          userName: "Manu",
          userPassword: "manu@123",
          userEmailId: "manu123@gmail.com",
          migrationType: "Advanced",
          domainName: "www.godaddy.com",
        }
      }
    ]);
  }

}
class MockUserContextService {
  email: string = '47523@hexaware.com';
  firstName: string = 'Pankaj';
  lastName: string = 'Sable';
  getSubscription() {
  }
}
const event = {
  target: {
    value: '5'
  }
}

describe('RequestsListComponent', () => {
  let component: RequestsListComponent;
  let fixture: ComponentFixture<RequestsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RequestsListComponent],
      imports: [NgxPaginationModule,
        MatFormFieldModule,
        MatInputModule,
        MatDatepickerModule,
        MatNativeDateModule,
        BrowserAnimationsModule],

      providers: [
        {
          provide: ItsmConnectorService,
          useClass: MockItsmConnectorService
        },
        {
          provide: UserContextService,
          useClass: MockUserContextService
        }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should filter the list on the basis of request id', () => {
    expect(component).toBeTruthy();
    component.setRequestId(event);
    expect(component.filteredRequests.length).toEqual(2);
  });
  it('should display empty request list when request id is not found', () => {
    expect(component).toBeTruthy();
    event.target.value = 'abc';
    component.setRequestId(event);
    expect(component.filteredRequests.length).toEqual(0);
    event.target.value = '5';
    component.setRequestId(event);
    expect(component.filteredRequests.length).toEqual(2);
  });
  it('should filter the list on the basis of request type', () => {
    expect(component).toBeTruthy();
    event.target.value = '3';
    component.setItemType(event);
    expect(component.filteredRequests.length).toEqual(1);
  });
  it('should filter the list on the basis of status', () => {
    expect(component).toBeTruthy();
    event.target.value = 'p';
    component.setStatus(event);
    expect(component.filteredRequests.length).toEqual(1);
    event.target.value = '5';
    component.setRequestId(event);
    expect(component.filteredRequests.length).toEqual(1);
  });
  it('should sort request list on the basis of requestId', () => {
    expect(component).toBeTruthy();
    fixture.detectChanges();
    const requestIdFilter = fixture.nativeElement.querySelector('.requestTest');
    requestIdFilter.click();
    expect(component.filteredRequests[0].requestId).toEqual('5f3cf6b8cb5843f81fc5b000');
    requestIdFilter.click();
    fixture.detectChanges();
    expect(component.filteredRequests[0].requestId).toEqual('5f3cf6b8cb5843f81fc5bfff');
  });
  it('should sort request list on the basis of status', () => {
    expect(component).toBeTruthy();
    fixture.detectChanges();
    const statusSort = fixture.nativeElement.querySelector('.statusTest');
    statusSort.click();
    fixture.detectChanges();
    expect(component.filteredRequests[0].status).toEqual('Pending');
    statusSort.click();
    fixture.detectChanges();
    expect(component.filteredRequests[0].status).toEqual('Successful');
  });
  it('should sort request list on the basis of item type', () => {
    expect(component).toBeTruthy();
    fixture.detectChanges();
    const itemSort = fixture.nativeElement.querySelector('.itemTest');
    itemSort.click();
    fixture.detectChanges();
    expect(component.filteredRequests[0].requestType).toEqual('Migration');
    itemSort.click();
    fixture.detectChanges();
    expect(component.filteredRequests[0].requestType).toEqual('O365Migration');
  });
  it('should sort request list on the basis of item type', () => {
    expect(component).toBeTruthy();
    const dateSort = fixture.nativeElement.querySelector('.dateTest');
    dateSort.click();
    fixture.detectChanges();
    expect(component.filteredRequests[0].createdOn).toEqual('7/19/2020');
    dateSort.click();
    fixture.detectChanges();
    expect(component.filteredRequests[0].createdOn).toEqual('8/19/2020');
  });
  it('should clear the date filter and display initial list', () => {
    expect(component).toBeTruthy();
    spyOn(component, 'filterRequestList');
    component.clearDate();
    fixture.detectChanges();
    expect(component.creationDate).toEqual('');
    expect(component.filterRequestList).toHaveBeenCalled();
  });
  
});
