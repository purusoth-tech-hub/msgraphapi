import { Component, OnInit } from '@angular/core';
import { ItsmConnectorService } from 'src/app/services/itsm-connector.service';
import { UserContextService } from 'src/app/services/user-context.service';
import { FormControl } from '@angular/forms';


@Component({
  selector: 'app-requests-list',
  templateUrl: './requests-list.component.html',
  styleUrls: ['./requests-list.component.css']
})

export class RequestsListComponent implements OnInit {
  statusSorted: boolean = false;
  requestList: any;
  dateSorted: boolean = false;
  requestIdSorted: boolean = false;
  requestTypeSorted: boolean = false;
  userEmailId = 'manu123@gmail.com';
  obj: Date = new Date();
  userDetails: any;
  loggedInEmail: any;
  p: number = 1;
  openRequests: any[] = [];
  filteredRequests: any[] = [];
  requestId: string;
  itemType: string;
  creationDate: string;
  date = new FormControl((new Date()).toISOString());
  status: string;
  constructor(private _itsmConnectorService: ItsmConnectorService, private userContext: UserContextService) { }

  ngOnInit(): void {
    this.loggedInEmail = this.userContext.email;
    this.userDetails = this.userContext.getSubscription();
    this._itsmConnectorService.getAllRequests().subscribe((res: any) => {
      this.requestList = res;
      this.openRequests = res;
      this.filteredRequests = res;
      // console.debug('this is not woorking', this.filteredRequests)
      // if (this.requestList) {
      //   this.requestList.forEach(element => {
      //     if (element.requestDetails.userEmailId === this.userEmailId) {
      //       this.openRequests.push(element);
      //       this.filteredRequests.push(element);
      //     }
      //   });
      // }
    });
  }
  setRequestId(event: any) {
    this.requestId = event.target.value;
    this.filterRequestList();
  }
  setItemType(event: any) {
    this.itemType = event.target.value;
    this.filterRequestList();
  }
  setStatus(event: any) {
    this.status = event.target.value;
    this.filterRequestList();
  }
  setDate() {
    var month: any;
    var day: any;
    var year: any

    month = this.date.value.getMonth() + 1;
    day = this.date.value.getDate();
    year = this.date.value.getFullYear();
    this.creationDate = month + '/' + day + '/' + year;
    this.filterRequestList();
  }
  filterRequestList() {
    this.filteredRequests = this.openRequests;
    this.filteredRequests = this.openRequests.filter(res => {
      return (this.requestId ? (res.requestId.toLowerCase().indexOf(this.requestId.toLowerCase()) !== -1) : 1) &&
        (this.itemType ? (res.requestType.toLowerCase().indexOf(this.itemType.toLowerCase()) !== -1) : 1) &&
        (this.creationDate ? (res.createdOn.toLowerCase().indexOf(this.creationDate.toLowerCase()) !== -1) : 1) &&
        (this.status ? (res.status.toLowerCase().indexOf(this.status.toLowerCase()) !== -1) : 1)
        ;
    });
  }
  sortStatus() {
    if (!this.statusSorted) {
      this.filteredRequests.sort((a, b) => a.status < b.status ? -1 : a.status > b.status ? 1 : 0);
      this.statusSorted = true;
    } else {
      this.filteredRequests.sort((a, b) => a.status > b.status ? -1 : a.status < b.status ? 1 : 0);
      this.statusSorted = false;
    }
  }
  sortDate() {
    if (!this.dateSorted) {
      this.filteredRequests.sort((a, b) => a.createdOn < b.createdOn ? -1 : a.createdOn > b.createdOn ? 1 : 0);
      this.dateSorted = true;
    } else {
      this.filteredRequests.sort((a, b) => a.createdOn > b.createdOn ? -1 : a.createdOn < b.createdOn ? 1 : 0);
      this.dateSorted = false;
    }
  }
  sortRequestId() {
    if (!this.requestIdSorted) {
      this.filteredRequests.sort((a, b) => a.requestId < b.requestId ? -1 : a.requestId > b.requestId ? 1 : 0);
      this.requestIdSorted = true;
    } else {
      this.filteredRequests.sort((a, b) => a.requestId > b.requestId ? -1 : a.requestId < b.requestId ? 1 : 0);
      this.requestIdSorted = false;
    }
  }
  sortRequestType() {
    if (!this.requestTypeSorted) {
      this.filteredRequests.sort((a, b) => a.requestType < b.requestType ? -1 : a.requestType > b.requestType ? 1 : 0);
      this.requestTypeSorted = true;
    } else {
      this.filteredRequests.sort((a, b) => a.requestType > b.requestType ? -1 : a.requestType < b.requestType ? 1 : 0);
      this.requestTypeSorted = false;
    }
  }
  clearDate() {
    this.creationDate = '';
    this.filterRequestList();
  }
}
