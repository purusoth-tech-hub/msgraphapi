import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { O365ExchangeOnlineCreateDistributionListComponent } from './o365-exchange-online-create-distribution-list.component';

describe('O365ExchangeOnlineCreateDistributionListComponent', () => {
  let component: O365ExchangeOnlineCreateDistributionListComponent;
  let fixture: ComponentFixture<O365ExchangeOnlineCreateDistributionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ O365ExchangeOnlineCreateDistributionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(O365ExchangeOnlineCreateDistributionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
