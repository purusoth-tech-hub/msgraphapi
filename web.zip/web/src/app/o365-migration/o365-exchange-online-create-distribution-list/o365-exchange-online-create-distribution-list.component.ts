import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ItsmConnectorService } from 'src/app/services/itsm-connector.service';
import { DistributionList } from 'src/app/models/distributionList';
import { O365Service } from 'src/app/services/o365.service';
import { Router, ActivatedRoute } from '@angular/router';
declare let $;

@Component({
  selector: 'app-o365-exchange-online-create-distribution-list',
  templateUrl: './o365-exchange-online-create-distribution-list.component.html',
  styleUrls: ['./o365-exchange-online-create-distribution-list.component.css']
})
export class O365ExchangeOnlineCreateDistributionListComponent implements OnInit {
  inProgress: boolean;
  formGroupDistributionList: FormGroup;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute,
    private _o365Service: O365Service) {
    this.formGroupDistributionList = new FormGroup({   
      Id: new FormControl('', Validators.required),      
      displayName: new FormControl('', Validators.required),
      owners: new FormControl('', Validators.required),
      members: new FormControl('', Validators.required)        
    });
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(){
    $(".js-form-item").bind("click", function () {
      $(this).addClass('form-item--input-filled');
    });
    
    $(".form-item__input").bind("blur", function () {
      if($(this).val() === '') {
          $(this).parent('.js-form-item').removeClass('form-item--input-filled');
      }
    }).bind("focus", function () {
      $(this).parent('.js-form-item').addClass('form-item--input-filled');
    });
  }

  createDistributionList() {
    this.inProgress = true;
    
    let distributionList = new DistributionList();
    
    distributionList.displayName = this.formGroupDistributionList.value.displayName;
    let owners = this.formGroupDistributionList.value.owners.split(';');
    distributionList.owners = owners;
    let members = this.formGroupDistributionList.value.members.split(';');
    distributionList.members = members;
    
      console.log(distributionList);
      this._o365Service.createDistributionList(distributionList)
        .subscribe((res: string) => {
          alert("Distribution List Created Successfully ");
        }, err => {
          alert("Distribution List Created Successfully ");
          this.inProgress = false;
        });    
  }
  cancelClick(){
    this._router.navigate(['/o365/supportServiceCatalog']);
  }

}
