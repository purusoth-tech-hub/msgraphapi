import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MsalGuard } from '@azure/msal-angular';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AzureSupportComponent } from './azure-support/azure-support.component';
import { O365DashboardComponent } from './o365-migration/o365-dashboard/o365-dashboard.component';
import { ProductsComponent } from './o365-migration/products/products.component';
import { ConnectAssessMigrateComponent } from './o365-migration/connect-assess-migrate/connect-assess-migrate.component';
import { RequestsComponent } from './o365-migration/requests/requests.component';
import { HomeComponent } from './home/home.component';
import { RequestDetailsComponent } from './o365-migration/requests/request-details/request-details.component';
import { O365ServiceCatalogComponent } from './o365-migration/o365-service-catalog/o365-service-catalog.component';
import { O365ExchangeOnlineCreatemailboxComponent } from './o365-migration/o365-exchange-online-createmailbox/o365-exchange-online-createmailbox.component';
import { O365ExchangeOnlineDeletemailboxComponent } from './o365-migration/o365-exchange-online-deletemailbox/o365-exchange-online-deletemailbox.component';
import { O365ExchangeOnlineCreateContactComponent } from './o365-migration/o365-exchange-online-create-contact/o365-exchange-online-create-contact.component';
import { O365ExchangeOnlineDeleteContactComponent } from './o365-migration/o365-exchange-online-delete-contact/o365-exchange-online-delete-contact.component';
import { O365ExchangeOnlineCreateDistributionListComponent } from 'src/app/o365-migration/o365-exchange-online-create-distribution-list/o365-exchange-online-create-distribution-list.component';
import { O365ExchangeOnlineDeleteDistributionListComponent } from 'src/app/o365-migration/o365-exchange-online-delete-distribution-list/o365-exchange-online-delete-distribution-list.component';

@NgModule({
  imports: [RouterModule.forChild([
    {
      path: 'o365',
      component: HomeComponent,
      children: [
        {
          path: 'dashboard',
          component: O365DashboardComponent,
          canActivate: [
            MsalGuard
          ]
        },
        {
          path: 'product',
          component: ProductsComponent
        },
        {
          path: 'migrate',
          component: ConnectAssessMigrateComponent
        },
        {
          path: 'requests',
          component: RequestsComponent
        },
        {
          path: 'requestDetails',
          component: RequestDetailsComponent
        },
        {
          path: 'supportServiceCatalog',
          component: O365ServiceCatalogComponent
        },
        {
          path: 'exchangeOnlineCreateMailBox',
          component: O365ExchangeOnlineCreatemailboxComponent
        },
        {
          path: 'exchangeOnlineDeleteMailBox',
          component: O365ExchangeOnlineDeletemailboxComponent
        },
        {
          path: 'exchangeOnlineCreateContact',
          component: O365ExchangeOnlineCreateContactComponent
        },
        {
          path: 'exchangeOnlineDeleteContact',
          component: O365ExchangeOnlineDeleteContactComponent
        },
        {
          path: 'exchangeOnlineCreateDistributionList',
          component: O365ExchangeOnlineCreateDistributionListComponent
        },
        {
          path: 'exchangeOnlineDeleteDistributionList',
          component: O365ExchangeOnlineDeleteDistributionListComponent
        }
      ]
    }
  ])],
  exports: [RouterModule],

})
export class AppRoutingModule { }
