import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { UserContextService } from '../services/user-context.service';
import { Router, NavigationStart, NavigationEnd } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  username: any;
  loggedIn: boolean;
  loggedInEmail;
  constructor(private _authService: AuthService, private userContext: UserContextService) { }

  ngOnInit() {
 
    this._authService.initializeAuthentication();
    this.loggedIn = this._authService.loggedIn;
    this.loggedInEmail = this.userContext.email;
    this.username = this.userContext.firstName + ' ' + this.userContext.LastName;
    this.userContext.getSubscription();
  }
  get dashboardActive() {
    return window.location.toString().search('/dashboard') > 0;
  }
  get productActive() {
    return (window.location.toString().search('/product') > 0) || (window.location.toString().search('/migrate') > 0);
  }

  get myRequestsActive(){
    return window.location.toString().search('/request') > 0;
  }
  logout() {
    this._authService.logout();
  }

}
