import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderComponent } from './header.component';
import { AuthService } from '../services/auth.service';
import { MsalService } from '@azure/msal-angular';
import { UserContextService } from '../services/user-context.service';
class MockAuthService {
  loggedIn = false;
  initializeAuthentication() {
    this.loggedIn = true;
  }
  logout() {
    this.loggedIn = false;
  }
}
class MockUserContextService {
  email: string = '47523@hexaware.com';
  firstName: string = 'Pankaj';
  lastName: string = 'Sable';
  getSubscription() {
  }
}

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [HeaderComponent],
      providers: [
        {
          provide: AuthService,
          useClass: MockAuthService
        },
        {
          provide: UserContextService,
          useClass: MockUserContextService
        }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
