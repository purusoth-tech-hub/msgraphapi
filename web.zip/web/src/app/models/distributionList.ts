import { ArrayType } from '@angular/compiler/src/output/output_ast';

export class DistributionList {
    Id: string    
    displayName: string
    owners: string[]
    members: string[]   
}

