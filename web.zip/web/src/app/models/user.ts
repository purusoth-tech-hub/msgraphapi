export class User {
    Id: string
    userPrincipalName: string
    displayName: string
    officeLocation: string
    mail: string    
    license: string
}

