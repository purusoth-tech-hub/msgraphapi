export class Contact {
    Id: string
    ownerEmail: string
    contactName: string
    contactNumber: string
    displayName: string
    contactEmail : string       
}