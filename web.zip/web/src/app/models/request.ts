export class Request {
    requestId: string
    requestType: string
    status: string
    createdOn: string
    updatedOn: string
    requestDetails: RequestDetail
}

export class ConnectionDetail {
    url: string
    userName: string
    password: string
}

export class RequestDetail {
    userName: string
    userPassword: string
    userEmailId: string
    migrationType: string
    domainName: string
    sourceConnection: ConnectionDetail
    targetConnection: ConnectionDetail
    dnsConnection: ConnectionDetail
    vpnConnection: ConnectionDetail
}