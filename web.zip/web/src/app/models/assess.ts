export class Assess {
    migratedOn: string;
    totalCost: string;
    mailBoxSize: string;
    totalUsers: string;
    licensesDetail: LicenceDetails;
}

export class LicenceDetails {
    totalLicense: string;
    totalUsers: string;
    userDetails: UserDetails[];
}

export class UserDetails {
    name: string;
    email: string;
    mailBoxSize: string;
    licenseType: string;
}