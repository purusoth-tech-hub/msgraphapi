// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
import { b2cPolicies } from 'src/app/app-config';
import {  Configuration } from 'msal';
// import { Configuration } from 'msal';

// import { b2cPolicies } from 'src/app/app-config';
export const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;
export const b2cAuthority = "https://azureitops.b2clogin.com/azureitops.onmicrosoft.com/B2C_1_signupsignin1";
 
export const environment = {
  production: true,
  // version: '{BUILD_VERSION}',
  apiUrl:'https://app-itops-azure-support-dev.azurewebsites.net',
  b2cPolicies : {
    names: {
        signUpSignIn: "B2C_1_signupsignin1",
        resetPassword: "b2c_1_reset",
    },
    authorities: {
        signUpSignIn: {
            authority: b2cAuthority
        },
        resetPassword: {
            authority: "https://fabrikamb2c.b2clogin.com/fabrikamb2c.onmicrosoft.com/b2c_1_reset"
        }
    }
},
apiConfig: {
  b2cScopes: ['https://azureitops.onmicrosoft.com/azure-support-api/General'],
  webApi: 'https://azureitops.onmicrosoft.com/azure-support-api'
},
msalConfig : {
  auth: {
      clientId: "b2d2233c-a69a-46f9-aa53-58cf218f91ec",
      authority: b2cAuthority,
      redirectUri: "https://app-itops-web-dev.azurewebsites.net/",
      postLogoutRedirectUri: "https://app-itops-web-dev.azurewebsites.net/",
      navigateToLoginRequestUrl: true,
      validateAuthority: false,
    },
  cache: {
      cacheLocation: "localStorage",
      storeAuthStateInCookie: isIE, // Set this to "true" to save cache in cookies to address trusted zones limitations in IE
  },
}
};
export const loginRequest = {
  scopes: ["openid", "profile"],
};

// Add here scopes for access token to be used at the API endpoints.
export const tokenRequest = {
  scopes: ['https://azureitops.onmicrosoft.com/azure-support-api/General'],  // e.g. ["https://fabrikamb2c.onmicrosoft.com/helloapi/demo.read"]
};



/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
