using ITOpsAutomation.O365Support.Data.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Core.Bindings;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Data.Repositories
{
    public class AssessRepository : IGetById<MigrationDetail, string>
    {
        private IMongoDBGateway _gateway;
        private string _collectionName = "Assess";

        public AssessRepository(IMongoDBGateway gateway)
        {
            _gateway = gateway;
        }
       
        public MigrationDetail GetById(string id)
        {
            var result = _gateway.GetMongoDB().GetCollection<MigrationDetail>(_collectionName)
                         .Find(o => o.RequestId == id)
                         .SingleOrDefault();
            return result;
        }
    }
}
