using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Data.Interfaces
{
    public interface ISave<T> where T : class
    {
        T Save(T entity);
    }
}
