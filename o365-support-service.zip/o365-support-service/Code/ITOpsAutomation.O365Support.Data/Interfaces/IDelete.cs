﻿namespace ITOpsAutomation.O365Support.Data.Interfaces
{
    public interface IDelete<T>
    {
        bool Delete(T id);
    }
}
