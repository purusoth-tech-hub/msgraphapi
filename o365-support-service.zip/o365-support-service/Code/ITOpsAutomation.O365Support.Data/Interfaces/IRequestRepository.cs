using ITOpsAutomation.O365Support.Entities.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Data.Interfaces
{
    public interface IRequestRepository : ISave<Request>
    {
        IEnumerable<Request> GetByUser(string userEmailId);

        Request GetById(string id);
    }
}
