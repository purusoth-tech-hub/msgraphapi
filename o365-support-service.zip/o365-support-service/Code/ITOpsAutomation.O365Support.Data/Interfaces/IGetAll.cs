using System.Collections.Generic;

namespace ITOpsAutomation.O365Support.Data.Interfaces
{
    public interface IGetAll<T> where T : class
    {
        IEnumerable<T> GetAll();
    }
}