using MongoDB.Driver;

namespace ITOpsAutomation.O365Support.Data.Interfaces
{
    public interface IMongoDBGateway
    {
        IMongoDatabase GetMongoDB();
    }
  
}
