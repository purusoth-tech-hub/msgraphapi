using ITOpsAutomation.O365Support.Data.Interfaces;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Text;

namespace ITOpsAutomation.Management.Data.Repositories
{
    public class MongoDBGateway : IMongoDBGateway
    {
        private IConfiguration _configuration;
        public MongoDBGateway(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public IMongoDatabase GetMongoDB()
        {
            string url = _configuration.GetSection("Cosmos")["URL"];
            string userName = _configuration.GetSection("Cosmos")["UserName"];
            string password = _configuration.GetSection("Cosmos")["Password"];
            string database = _configuration.GetSection("Cosmos")["Database"];

            MongoClientSettings settings = new MongoClientSettings();
            settings.Server = new MongoServerAddress(url, 10255);
            settings.UseTls = true;
            settings.SslSettings = new SslSettings();
            settings.SslSettings.EnabledSslProtocols = SslProtocols.Tls12;
            settings.RetryWrites = false;

            MongoIdentity identity = new MongoInternalIdentity(database, userName);
            MongoIdentityEvidence evidence = new PasswordEvidence(password);

            settings.Credential = new MongoCredential("SCRAM-SHA-1", identity, evidence);

            MongoClient client = new MongoClient(settings);
            return client.GetDatabase(database);

        }
    }
}
