using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ITOpsAutomation.O365Support.Entities.Entities;
namespace ITOpsAutomation.O365Support.Business.Gateway.Interfaces
{
    public interface IServiceNowGateway 
    {
        Task<Request> Create(Request ticketDetails);
    }
}
