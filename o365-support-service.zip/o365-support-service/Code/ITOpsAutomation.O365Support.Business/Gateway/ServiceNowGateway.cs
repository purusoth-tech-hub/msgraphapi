using ITOpsAutomation.O365Support.Business.Gateway.Interfaces;
using System;
using System.Net.Http;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text;
using Newtonsoft.Json;
using RestSharp.Authenticators;
using RestSharp.Deserializers;
using RestSharp.Serialization;
using Microsoft.Extensions.Configuration;
using RestSharp;
using ITOpsAutomation.O365Support.Common.Helpers.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities;

namespace ITOpsAutomation.O365Support.Business.Gateway.Services
{
    public class ServiceNowGateway : IServiceNowGateway
    {
        private readonly IRestClient _client;
        public IConfiguration _configuration { get; }
        //private readonly IApiClient _apiClient;
        //private string service = "ServiceNow";
        public ServiceNowGateway(IRestClient client, IConfiguration configuration)
        {
            _client = client;
            _configuration = configuration;
        }

        public async Task<Request> Create(Request request)
        {
            var content = JsonConvert.SerializeObject(request); 
            _client.BaseUrl = new Uri(_configuration["ServiceNowSettings:BaseUrl"]);
            _client.Authenticator = new HttpBasicAuthenticator(_configuration["ServiceNowSettings:Id"], _configuration["ServiceNowSettings:Password"]);
            _client.AddDefaultHeader("Content-Type", "application/json");

            RestRequest restRequest = new RestRequest(Method.POST);
            restRequest.AddParameter("undefined", content, ParameterType.RequestBody);
            IRestResponse response = await _client.ExecutePostAsync(restRequest);
            if(response.ResponseStatus != ResponseStatus.Completed)
            {
                throw new Exception("Cannot create the Request Ticket");
            }
            return JsonConvert.DeserializeObject<Request> (response.Content);
        }    

        // This need to be used while making call to external API using this Common api client managing class
        // public async Task<Request> Create(Request request)
        // {
        //     return await _apiClient.Post(service,"CreateRequest", request, "Basic");
        // }     
    }
}
