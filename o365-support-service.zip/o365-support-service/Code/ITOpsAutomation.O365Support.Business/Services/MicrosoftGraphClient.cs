﻿using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using ITOpsAutomation.O365Support.Business.Gateway.Interfaces;
using ITOpsAutomation.O365Support.Data.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Common = ITOpsAutomation.O365Support.Common;

namespace ITOpsAutomation.O365Support.Business.Services
{
    public static class MicrosoftGraphClient
    {
        private static GraphServiceClient graphClient;   
        private static string clientId;
        private static string clientSecret;
        private static string tenantId;
        private static string aadInstance;
        private static string graphResource;
        private static string graphAPIEndpoint;
        private static string authority;     
          

        public static async Task<GraphServiceClient> GetGraphServiceClient(AzureAD azureAD)
        {
            // Get Access Token and Microsoft Graph Client using access token and microsoft graph v1.0 endpoint
            var delegateAuthProvider = await GetAuthProvider(azureAD);
            // Initializing the GraphServiceClient
            graphAPIEndpoint = $"{Common.Constants.GRAPH_RESOURCE}{Common.Constants.GRAPH_RESOURCE_ENDPOINT}";
            graphClient = new GraphServiceClient(graphAPIEndpoint, delegateAuthProvider);

            return graphClient;
        }        

        private static async Task<IAuthenticationProvider> GetAuthProvider(AzureAD azureAD)
        {
            authority = $"{Common.Constants.INSTANCE}{azureAD.TenantId}";            
            AuthenticationContext authenticationContext = new AuthenticationContext(authority);
            ClientCredential clientCred = new ClientCredential(azureAD.ClientId, azureAD.ClientSecret);

                       // ADAL includes an in memory cache, so this call will only send a message to the server if the cached token is expired.
            AuthenticationResult authenticationResult = await authenticationContext.AcquireTokenAsync(Common.Constants.GRAPH_RESOURCE, clientCred);
            var token = authenticationResult.AccessToken;

            var delegateAuthProvider = new DelegateAuthenticationProvider((requestMessage) =>
            {
                requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", token.ToString());
                return Task.FromResult(0);
            });

            return delegateAuthProvider;
        }        
    }
}
