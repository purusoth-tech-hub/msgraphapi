﻿using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using ITOpsAutomation.O365Support.Business.Gateway.Interfaces;
using ITOpsAutomation.O365Support.Data.Interfaces;
using Model = ITOpsAutomation.O365Support.Entities.Entities;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;

namespace ITOpsAutomation.O365Support.Business.Services
{
    public class ExchangeOnlineService : IExchangeOnlineService
    {
        IServiceNowGateway _serviceNowGateway;
        
        public ExchangeOnlineService(IServiceNowGateway serviceNowGateway)
        {
            this._serviceNowGateway = serviceNowGateway;          
        }  

        public async Task<Model.User> UserById(Model.AzureAD azureAD, string id)
        {
            try
            {
                // Initialize the GraphServiceClient.
                GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);

                // Load group profile.
                 var _user = await client.Users[id].Request().GetAsync();
                 Model.User user = new Model.User();
                 if(_user != null){
                     user.id = _user.Id;
                     user.givenName = _user.GivenName;    
                     user.userPrincipalName = _user.UserPrincipalName;  
                     user.displayName = _user.DisplayName;
                     user.officeLocation = _user.OfficeLocation;
                 }
                return user;
            }
            catch (ServiceException ex)
            {
               throw ex;
            }
        } 
        public async Task<string> CreateUser(Model.AzureAD azureAD, Model.User userInfo)
        {
           try
           {
               // Initialize the GraphServiceClient.
               GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);
               Microsoft.Graph.User user = new Microsoft.Graph.User();

               Microsoft.Graph.PasswordProfile passwordProfile = new Microsoft.Graph.PasswordProfile();
               passwordProfile.Password = string.Format("Password@{0}",new Guid().ToString().Substring(0,5));
               passwordProfile.ForceChangePasswordNextSignIn = true;
               user.PasswordProfile = passwordProfile;

               user.UserPrincipalName = userInfo.userPrincipalName;

               user.AccountEnabled = userInfo.accountEnabled;
               
               user.Country = userInfo.country;
               user.Department = userInfo.department;
               user.DisplayName = userInfo.displayName;
               user.GivenName = userInfo.givenName;
               user.Surname = userInfo.surname; 
               user.JobTitle = userInfo.jobTitle;
               user.MailNickname = userInfo.mailNickname;

               user.PasswordPolicies = "DisablePasswordExpiration";
                              
               user.StreetAddress = userInfo.streetAddress;
               user.City = userInfo.city;
               user.State = userInfo.state;    
               user.PostalCode = userInfo.postalCode;
               user.MobilePhone = userInfo.mobilePhone;
               user.OfficeLocation = userInfo.officeLocation;
               //user.UsageLocation = userInfo.usageLocation;              

               // Load group profile.
               var _user = await client.Users.Request().AddAsync(user);

               return _user.Id;
           }
           catch (ServiceException ex)
           {
              throw ex;
           }
        }

    }
}
