﻿using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using ITOpsAutomation.O365Support.Business.Gateway.Interfaces;
using ITOpsAutomation.O365Support.Data.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Business.Services
{
    public class ExchangeOnlineService : IExchangeOnlineService
    {
        IServiceNowGateway _serviceNowGateway;
        
        public ExchangeOnlineService(IServiceNowGateway serviceNowGateway)
        {
            this._serviceNowGateway = serviceNowGateway;          
        }  

        public async Task<User> UserById(AzureAD azureAD, string id)
        {
            try
            {
                // Initialize the GraphServiceClient.
                GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);

                // Load group profile.
                 var _user = await client.Users[id].Request().GetAsync();

                return _user;
            }
            catch (ServiceException ex)
            {
               throw ex;
            }
        }        

        public async Task<User> CreateUser(AzureAD azureAD, User userInfo)
        {
            try
            {
                // Initialize the GraphServiceClient.
                GraphServiceClient client = await MicrosoftGraphClient.GetGraphServiceClient(azureAD);

                // Load group profile.
                var _user = await client.Users.Request().AddAsync(userInfo);

                return _user;
            }
            catch (ServiceException ex)
            {
                throw ex;
            }
        }
    }
}
