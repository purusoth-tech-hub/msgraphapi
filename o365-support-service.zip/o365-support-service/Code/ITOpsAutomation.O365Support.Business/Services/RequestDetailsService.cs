using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities;
using ITOpsAutomation.O365Support.Business.Gateway.Interfaces;
using ITOpsAutomation.O365Support.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Business.Services
{
    
    public class RequestDetailsService : IRequestDetailsService
    {
        IServiceNowGateway _serviceNowGateway;
        IRequestRepository _requestRepository;

        public RequestDetailsService(IServiceNowGateway serviceNowGateway, IRequestRepository requestRepository)
        {
           this._serviceNowGateway = serviceNowGateway;
           this._requestRepository = requestRepository;
        }


        public Request Create(Request request)
        {
            request.CreatedOn = DateTime.UtcNow.ToShortDateString();
            request.UpdatedOn = DateTime.UtcNow.ToShortDateString();
            return _requestRepository.Save(request);
        }

        public IEnumerable<Request> GetByUser()
        {
            string userEmailId = "manu123@gmail.com"; //userEmailId need to be extracted from the token
            return _requestRepository.GetByUser(userEmailId);
        }

        public Request GetById(string id)
        {
            return _requestRepository.GetById(id);
        }
    }
}
