﻿using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITOpsAutomation.O365Support.Business.Services.Interfaces
{
    public interface IAssessService 
    {
        MigrationDetail GetById(string id);
    }
}
