using ITOpsAutomation.O365Support.Entities.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Business.Services.Interfaces
{
    public interface IRequestDetailsService
    {
        Request Create(Request request);

        IEnumerable<Request> GetByUser();

        Request GetById(string id);
    }
}
