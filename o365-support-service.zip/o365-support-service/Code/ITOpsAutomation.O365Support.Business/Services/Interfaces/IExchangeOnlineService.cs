﻿using ITOpsAutomation.O365Support.Entities.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Business.Services.Interfaces
{
    public interface IExchangeOnlineService 
    {
        Task<User> UserById(AzureAD azureAD, string id);
        Task<User> CreateUser(AzureAD azureAD, User user);
        // void DeleteUser(string id);
        // void CreateContact(Contact contact);
        // void DeleteContact(string emailAddress);
        // void CreateDistributionList(DistributionGroup distributionGroup);
        // void DeleteDistributionList(string id);
        // void UpdateDistributionList(string id, DistributionGroup distributionGroup);
    }
}
