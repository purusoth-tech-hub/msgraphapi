using ITOpsAutomation.O365Support.Data.Installer;
using Microsoft.Extensions.DependencyInjection;
using Scrutor;
using RestSharp;
namespace ITOpsAutomation.O365Support.Business.Installer
{
    public class ServiceInstaller
    {
        private IServiceCollection _service;
        public ServiceInstaller(IServiceCollection service)
        {
            _service = service;
        }

        public void Install()
        {
            _service.Scan(scan => scan
                                    .FromAssemblyOf<ServiceInstaller>()
                                    .AddClasses()
                                    .AsImplementedInterfaces()
                                    .WithScopedLifetime());
            _service.AddScoped<IRestClient,RestClient>();
            var dataInstaller = new DataInstaller(_service);
            dataInstaller.Install();
        }
    }
}
