﻿namespace ITOpsAutomation.O365Support.Entities.Entities.Assess
{
    public class UserDetail
    {
        public string Name { get; set; }
        public string Email { get; set; }

        public int MailBoxSize { get; set; }
        public LicenseType LicenseType { get; set; }
    }
}
