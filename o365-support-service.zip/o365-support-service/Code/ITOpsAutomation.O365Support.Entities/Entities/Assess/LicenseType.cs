﻿namespace ITOpsAutomation.O365Support.Entities.Entities.Assess
{
    public enum LicenseType
    {
        Office365BusinessEssentials,
        Office365BusinessPremium,
        Office365ExchangeOnly,
        EnterprisePlanE,
        Office365PlanE2
    }
}
