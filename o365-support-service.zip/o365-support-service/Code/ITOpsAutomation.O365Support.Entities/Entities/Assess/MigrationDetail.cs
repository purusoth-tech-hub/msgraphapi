﻿using System;
using System.Text;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace ITOpsAutomation.O365Support.Entities.Entities.Assess
{
    [BsonIgnoreExtraElements]
    public class MigrationDetail
    {
        public string RequestId { get; set; }
        public DateTime MigratedOn { get; set; }

        public double TotalCost { get; set; }

        public int MailBoxSize { get; set; }

        public int TotalUsers { get; set; }

        public LicensesDetail LicensesDetail { get; set; }
    }
}
