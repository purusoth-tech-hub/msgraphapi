﻿using System.Collections.Generic;

namespace ITOpsAutomation.O365Support.Entities.Entities.Assess
{
    public class LicensesDetail
    {
        public int TotalLicense { get; set; }

        public int TotalUsers { get; set; }

        public IEnumerable<UserDetail> UserDetails { get; set; }

    }
}
