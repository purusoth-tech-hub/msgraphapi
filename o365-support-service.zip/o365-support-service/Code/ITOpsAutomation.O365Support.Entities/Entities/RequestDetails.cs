using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace ITOpsAutomation.O365Support.Entities.Entities
{
    public class RequestDetails
    {
        public string UserName { get; set; }
        public string UserPassword { get; set; }
        [BsonRequired]
        public string UserEmailId { get; set; } 
        public string MigrationType { get; set; }
        public string DomainName { get; set; }
        public ServiceConnection SourceConnection {get; set;} 
        public ServiceConnection TargetConnection {get; set;} 
        public ServiceConnection DnsConnection {get; set;} 
        public ServiceConnection VpnConnection {get; set;} 

    }
}
