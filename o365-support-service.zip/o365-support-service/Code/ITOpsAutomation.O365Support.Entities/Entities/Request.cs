using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace ITOpsAutomation.O365Support.Entities.Entities
{
    [BsonIgnoreExtraElements]
    public class Request
    {
        [BsonRequired]
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        [BsonElement("Id")]
        public string RequestId { get; set; }
        [BsonRequired]
        public string RequestType { get; set; }
        [BsonRequired]
        public string Status { get; set; }  
        public string CreatedOn {get ; set; }
        public string UpdatedOn {get ; set; }
        public RequestDetails RequestDetails { get; set; }
    }

}
