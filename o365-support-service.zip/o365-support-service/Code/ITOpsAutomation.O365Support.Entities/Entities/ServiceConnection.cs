using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace ITOpsAutomation.O365Support.Entities.Entities
{
    public class ServiceConnection
    {
        public string Url { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }
    }

}
