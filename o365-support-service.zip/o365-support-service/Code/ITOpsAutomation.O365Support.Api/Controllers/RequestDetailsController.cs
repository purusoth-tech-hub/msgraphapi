﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using FluentValidation.Results;
using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ITOpsAutomation.O365Support.Api.Filters;

namespace ITOpsAutomation.Management.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestDetailsController : ControllerBase
    {
        IRequestDetailsService _requestDetailsService;
        public RequestDetailsController(IRequestDetailsService requestDetailsService)
        {
            _requestDetailsService = requestDetailsService;
        }

        [HttpPost("Create")]
        public ActionResult<Request> Create(Request request)
        {
            return Ok(_requestDetailsService.Create(request));
        }

        [HttpGet("GetAllByUser")]
        public ActionResult<IEnumerable<Request>> GetAllByUser()
        {
            return Ok(_requestDetailsService.GetByUser());
        }

        [HttpGet("GetById/{id}")]
        public ActionResult<Task<Request>> GetById([FromRoute] string id)
        {
            return Ok(_requestDetailsService.GetById(id));
        }

    }
}
