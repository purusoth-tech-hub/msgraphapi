﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ITOpsAutomation.O365Support.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssessController : ControllerBase
    {
        IAssessService _assessService;
        public AssessController(IAssessService assessService)
        {
            _assessService = assessService;
        }


        [HttpGet("GetAssessDetails/{id}")]
        public ActionResult<Task<MigrationDetail>> GetAssessDetails([FromRoute] string id)
        {
            return Ok(_assessService.GetById(id));
        }

        
    }
}
