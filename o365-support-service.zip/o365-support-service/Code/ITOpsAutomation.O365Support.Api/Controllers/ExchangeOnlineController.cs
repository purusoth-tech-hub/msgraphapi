﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using Model = ITOpsAutomation.O365Support.Entities.Entities;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ITOpsAutomation.O365Support.Api.Filters;

namespace ITOpsAutomation.O365Support.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExchangeOnlineController : ControllerBase
    {
        IExchangeOnlineService _exchangeOnlineService;
        public ExchangeOnlineController(IExchangeOnlineService exchangeOnlineService)
        {
            _exchangeOnlineService = exchangeOnlineService;
        }

        [HttpPost("UserById/{id}")]
        public async Task<IActionResult> UserById(            
            string id)
        {
            Model.AzureAD azureAD = new Model.AzureAD();
            azureAD.ClientId = "06c151fe-f63f-4070-8fdf-53b26246fb19";
            azureAD.ClientSecret = "QYLTmQiBf02zK3w454W2i__e2gQ-3_Nc-H";
            azureAD.TenantId = "fbe96831-3e8d-40c2-b251-ee6bffb21e31";
            var _user = await _exchangeOnlineService.UserById(azureAD, id);
            return Ok(_user);
        }

        [HttpPost("CreateUser")]
        public async Task<IActionResult> CreateUser(            
            [FromBody]Model.User user)
        {
            Model.AzureAD azureAD = new Model.AzureAD();
            azureAD.ClientId = "06c151fe-f63f-4070-8fdf-53b26246fb19";
            azureAD.ClientSecret = "QYLTmQiBf02zK3w454W2i__e2gQ-3_Nc-H";
            azureAD.TenantId = "fbe96831-3e8d-40c2-b251-ee6bffb21e31";

            var id = await _exchangeOnlineService.CreateUser(azureAD, user);
            return Ok(id);
        }        
    }
}
