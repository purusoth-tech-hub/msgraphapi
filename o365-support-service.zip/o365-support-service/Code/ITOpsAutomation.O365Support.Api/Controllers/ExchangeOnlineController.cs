﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ITOpsAutomation.O365Support.Business.Services.Interfaces;
using ITOpsAutomation.O365Support.Entities.Entities;
using ITOpsAutomation.O365Support.Entities.Entities.Assess;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ITOpsAutomation.O365Support.Api.Filters;

namespace ITOpsAutomation.O365Support.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExchangeOnlineController : ControllerBase
    {
        IExchangeOnlineService _exchangeOnlineService;
        public ExchangeOnlineController(IExchangeOnlineService exchangeOnlineService)
        {
            _exchangeOnlineService = exchangeOnlineService;
        }

        [HttpGet("UserById/{id}")]
        public ActionResult<Task<User>> UserById([FromRoute] AzureAD azureAD, string id)
        {
            User _user = _exchangeOnlineService.UserById(azureAD, user);
            return Ok();
        }

        [HttpGet("CreateUser")]
        public ActionResult<Task<User>> CreateUser([FromRoute] AzureAD azureAD, User user)
        {
            User _user = _exchangeOnlineService.CreateUser(azureAD, user);
            return Ok();
        }        
    }
}
