using System.Collections.Generic;
using System.Threading.Tasks;

namespace ITOpsAutomation.O365Support.Common.Helpers.Interfaces
{
    public interface IApiClient
    {
        Task<T> Post<T>(string service, string action, T request, string authenticationType) where T : new();
    }
}
