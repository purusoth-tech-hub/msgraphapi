using System;
 
namespace ITOpsAutomation.O365Support.Common.Helpers
{
    public class ApiException : Exception
    {
        public ApiException(string message)
            : base(message)
        {
 
        }
    }
}